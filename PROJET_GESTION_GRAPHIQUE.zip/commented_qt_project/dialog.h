/**
 * @file dialog.h
 * @brief Teacher login dialog.
 *
 * Accepts a teacher code + password, then presents a menu of teacher actions:
 *   - Add / modify / delete students
 *   - Add / modify assessments and grades
 *   - View all students or class statistics
 *
 * Login rules:
 *   - Hard-coded admin account: username "admin" / password "admin"
 *   - Any teacher from the DB can log in with their code + password "Admin"
 */

#ifndef DIALOG_H
#define DIALOG_H

#include <QDialog>
#include <vector>
#include "etudiant.h"
#include "enseignant.h"

namespace Ui { class Dialog; }

/**
 * @class Dialog
 * @brief Teacher authentication and action-dispatch dialog.
 *
 * Holds pointers (not ownership) to the master etudiants/enseignants vectors.
 */
class Dialog : public QDialog
{
    Q_OBJECT

public:
    /**
     * @brief Constructs the teacher login dialog.
     * @param etudiants   Pointer to the main window's student list.
     * @param enseignants Pointer to the main window's teacher list.
     * @param parent      Parent widget.
     */
    explicit Dialog(vector<etudiant*>* etudiants,
                    vector<enseignant*>* enseignants,
                    QWidget *parent = nullptr);
    ~Dialog();

private slots:
    void on_pushButton_clicked();    ///< "SE CONNECTER" — validates credentials and shows the action menu
    void on_pushButton_2_clicked();  ///< "ANNULER" — closes the dialog

private:
    Ui::Dialog *ui;
    vector<etudiant*>*   etudiants;    ///< Non-owning pointer to the master student list
    vector<enseignant*>* enseignants;  ///< Non-owning pointer to the master teacher list

    // Hard-coded admin credentials (fallback when DB is unavailable)
    const QString ID_PROF      = "prof01";
    const QString MOT_DE_PASSE = "admin123";
};

#endif // DIALOG_H
