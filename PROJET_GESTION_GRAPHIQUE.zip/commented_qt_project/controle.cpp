/**
 * @file controle.cpp
 * @brief Implementation of the controle class.
 */

#include "controle.h"

/** Allocates the note object on the heap with the given initial value. */
controle::controle(string t, float p, float val) : type(t), pourcentage(p) {
    n = new note(val);
}

/** Frees the heap-allocated note. */
controle::~controle() { delete n; }

float controle::getNote() const { return n->getNote(); }
float controle::getPourcentage() const { return pourcentage; }
string controle::getType() const { return type; }

void controle::setNote(float val) { n->setNote(val); }
