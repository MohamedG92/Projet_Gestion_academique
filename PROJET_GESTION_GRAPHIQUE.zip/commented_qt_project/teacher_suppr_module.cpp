/**
 * @file teacher_suppr_module.cpp
 * @brief Implementation of the "delete module" teacher dialog.
 *
 * Locates the student by CNE, executes a DELETE SQL query,
 * then calls etudiant::supprimerModule to remove it from memory.
 */

#include "teacher_suppr_module.h"
#include "ui_teacher_suppr_module.h"
#include "database.h"
#include <QMessageBox>
#include <QtSql/QSqlQuery>

teacher_suppr_module::teacher_suppr_module(vector<etudiant*>* etudiants, QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::teacher_suppr_module)
    , etudiants(etudiants)
{
    ui->setupUi(this);
    connect(ui->pushButton_2, &QPushButton::clicked, this, &teacher_suppr_module::on_sauvegarder);
    connect(ui->pushButton,   &QPushButton::clicked, this, &QDialog::close);
}

teacher_suppr_module::~teacher_suppr_module() { delete ui; }

void teacher_suppr_module::on_sauvegarder()
{
    // lineEdit=CNE, lineEdit_2=code module
    QString cne  = ui->lineEdit->text().trimmed();
    QString code = ui->lineEdit_2->text().trimmed();

    if (cne.isEmpty() || code.isEmpty()) {
        QMessageBox::warning(this, "Erreur", "Veuillez remplir tous les champs."); return;
    }
    etudiant* cible = nullptr;
    for (int i = 0; i < (int)etudiants->size(); i++)
        if ((*etudiants)[i]->getCNE() == cne.toStdString()) { cible = (*etudiants)[i]; break; }

    if (!cible) { QMessageBox::warning(this, "Erreur", "Etudiant introuvable."); return; }

    QSqlQuery q;
    q.prepare("DELETE FROM modules WHERE etudiant_cin = :cin AND code = :code");
    q.bindValue(":cin",  QString::fromStdString(cible->getCIN()));
    q.bindValue(":code", code);
    q.exec();

    cible->supprimerModule(code.toStdString());
    QMessageBox::information(this, "Succes", "Module supprime !");
    ui->lineEdit->clear(); ui->lineEdit_2->clear();
}
