/**
 * @file enseignant.cpp
 * @brief Implementation of the enseignant class.
 */

#include "enseignant.h"

/** Delegates identity fields to personne, stores the teacher code locally. */
enseignant::enseignant(string cin_, string nom_, string prenom_, string code)
    : personne(cin_, nom_, prenom_), codeEnseignant(code) {}

string enseignant::getCode() const { return codeEnseignant; }
