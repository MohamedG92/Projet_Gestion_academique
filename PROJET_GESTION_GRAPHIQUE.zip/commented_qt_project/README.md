# Gestion Scolaire — Qt GUI Application

A Qt 6 academic management system with a graphical interface, connected to a local MariaDB database (via XAMPP). Two roles are supported: **Teacher** (full CRUD) and **Student** (read-only stats).

---

## Requirements

| Tool | Version | Notes |
|---|---|---|
| **Qt Creator** | 6.x (recommended) | Bundled with Qt 6 installer |
| **Qt** | 6.x (Qt 5 also works) | Must include `Widgets` and `Sql` modules |
| **XAMPP** | Any recent version | Provides MariaDB/MySQL on Windows |
| **MySQL ODBC Driver** | 9.x (Unicode) | Must match the driver string in `database.cpp` |
| **C++ compiler** | MinGW 64-bit (Windows) or GCC/Clang | Bundled with Qt installer |

---

## 1 — Install Qt

1. Download the Qt Online Installer from **[https://www.qt.io/download-open-source](https://www.qt.io/download-open-source)**.
2. Run the installer and create a free Qt account if prompted.
3. Under **Qt 6.x**, check:
   - `Desktop (MinGW 64-bit)` — the compiler toolkit
   - `Qt Sql` — required for database access
4. Also install **Qt Creator** (included in the default selection).
5. Complete the installation (may take several minutes).

---

## 2 — Install XAMPP and Start MySQL

1. Download XAMPP from **[https://www.apachefriends.org](https://www.apachefriends.org)** and install it.
2. Open the **XAMPP Control Panel**.
3. Click **Start** next to **MySQL**.
4. Once the status turns green, MySQL is running on `localhost:3306`.

---

## 3 — Install the MySQL ODBC Driver

The application connects via ODBC. You need the **MySQL ODBC 9.6 Unicode Driver**.

1. Go to **[https://dev.mysql.com/downloads/connector/odbc/](https://dev.mysql.com/downloads/connector/odbc/)**.
2. Download the **Windows (x86, 64-bit) MSI Installer** for version **9.x**.
3. Install it (default options are fine).
4. Verify it is registered:
   - Open **ODBC Data Source Administrator** (search in Start Menu).
   - Go to the **Drivers** tab.
   - You should see `MySQL ODBC 9.6 Unicode Driver` in the list.

> **If your driver version differs**, update the driver string in `database.cpp`:
> ```cpp
> db.setDatabaseName("DRIVER={MySQL ODBC 9.6 Unicode Driver};...");
> //                  ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
> // Change to match the exact name shown in the ODBC Drivers tab
> ```

---

## 4 — Create the Database

1. Open your browser and go to **[http://localhost/phpmyadmin](http://localhost/phpmyadmin)**.
2. Click **New** in the left sidebar and create a database named **`khdaminshalah`**.
3. Select the new database, click the **SQL** tab, paste the script below, and click **Go**:

```sql
CREATE TABLE etudiants (
    cin     VARCHAR(20) PRIMARY KEY,
    nom     VARCHAR(100) NOT NULL,
    prenom  VARCHAR(100) NOT NULL,
    cne     VARCHAR(20)  NOT NULL UNIQUE
);

CREATE TABLE enseignants (
    cin     VARCHAR(20) PRIMARY KEY,
    nom     VARCHAR(100) NOT NULL,
    prenom  VARCHAR(100) NOT NULL,
    code    VARCHAR(20)  NOT NULL UNIQUE
);

CREATE TABLE modules (
    id              INT AUTO_INCREMENT PRIMARY KEY,
    code            VARCHAR(20)  NOT NULL,
    intitule        VARCHAR(200) NOT NULL,
    coefficient     INT          NOT NULL DEFAULT 1,
    codeEnseignant  VARCHAR(20),
    semestre        INT          NOT NULL DEFAULT 1,
    etudiant_cin    VARCHAR(20),
    FOREIGN KEY (etudiant_cin) REFERENCES etudiants(cin) ON DELETE CASCADE
);

CREATE TABLE controles (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    type        VARCHAR(10)  NOT NULL,
    pourcentage FLOAT        NOT NULL,
    note        FLOAT        NOT NULL DEFAULT 0,
    module_id   INT,
    FOREIGN KEY (module_id) REFERENCES modules(id) ON DELETE CASCADE
);
```

4. (Optional) Insert a test teacher so you can log in:

```sql
INSERT INTO enseignants (cin, nom, prenom, code)
VALUES ('T001', 'Dupont', 'Jean', 'prof01');
```

---

## 5 — Open the Project in Qt Creator

1. Launch **Qt Creator**.
2. Click **Open Project** and select the `CMakeLists.txt` file in this folder.
3. Qt Creator will ask you to configure the project — select the **Desktop Qt 6.x MinGW 64-bit** kit and click **Configure Project**.
4. Wait for CMake to finish parsing the project.

---

## 6 — Build and Run

1. Click the green **Run** button (▶) or press `Ctrl + R`.
2. Qt Creator will compile and launch the application.
3. The app connects to the database on startup. If the connection fails, a warning is printed to the **Application Output** panel — the UI will still open but SQL features won't work.

---

## Login Credentials

### Teacher login
| Username | Password | Notes |
|---|---|---|
| `admin` | `admin` | Hard-coded fallback account |
| `prof01` | `Admin` | Any teacher `code` from the DB + password `Admin` |

### Student login
Enter the student's **CNE** (no password required).

---

## Assessment Weights

| Type | Weight |
|---|---|
| TP | 20 % |
| CC | 30 % |
| EXAM | 50 % |

Passing threshold: **10 / 20** (general weighted average).

---

## Project Structure

```
closest_thing/
├── CMakeLists.txt              # Build configuration (Qt 6/5 compatible)
├── main.cpp                    # Entry point
│
├── personne.h / .cpp           # Base class: CIN, nom, prenom
├── note.h / .cpp               # Grade value (0-20)
├── controle.h / .cpp           # Assessment: type, weight, grade
├── module.h / .cpp             # Course: code, coefficient, assessments
├── enseignant.h / .cpp         # Teacher (extends personne)
├── etudiant.h / .cpp           # Student (extends personne + modules)
│
├── database.h / .cpp           # Qt SQL CRUD layer (ODBC → MariaDB)
│
├── mainwindow.h / .cpp / .ui   # Landing screen (Teacher / Student buttons)
├── dialog.h / .cpp / .ui       # Teacher login + action menu
├── loginstudent.h / .cpp / .ui # Student login by CNE
├── studentstat.h / .cpp / .ui  # Student read-only stats view
│
├── teacher_ajouter_etu.*       # Add student
├── teacher_mod_etud.*          # Edit student
├── teacher_suppr_module.*      # Delete module
├── teacher_recher_etud.*       # Search student
├── teacher_ajout_control_module.* # Add assessment
├── teacher_modi_note.*         # Modify grade
├── teacher_affich_tout_etud.*  # List all students
└── teacher_stat.*              # Class statistics
```

---

## Troubleshooting

**"DB connection failed" in the output panel**
- Make sure XAMPP MySQL is running.
- Check that the MySQL ODBC driver name in `database.cpp` matches what is installed on your machine.
- Verify the database name is `khdaminshalah` (case-sensitive on Linux).

**Qt Sql module not found**
- Re-run the Qt installer and make sure `Qt Sql` is checked under your Qt version.

**Build errors about `QSqlDatabase`**
- Open `CMakeLists.txt` and confirm `Qt${QT_VERSION_MAJOR}::Sql` is in the `target_link_libraries` section (it is, by default).
