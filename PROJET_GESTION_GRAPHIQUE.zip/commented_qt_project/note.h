/**
 * @file note.h
 * @brief Stores a single grade value clamped to [0, 20].
 */

#ifndef NOTE_H
#define NOTE_H

#include <iostream>
using namespace std;

/**
 * @class note
 * @brief Represents a numeric grade in the Moroccan 0-20 scale.
 *
 * All setters clamp the value so it can never go below 0 or above 20.
 */
class note {
private:
    float n;  ///< The grade value (always in [0, 20])

public:
    /**
     * @brief Constructs a note with an optional initial value.
     * @param val  Initial grade (default 0).
     */
    note(float val = 0);

    /** @brief Reads a grade from stdin, clamping to [0, 20]. */
    void saisir();

    /** @brief Prints the grade to stdout. */
    void afficher() const;

    /** @brief Returns the stored grade value. */
    float getNote() const;

    /**
     * @brief Updates the grade, clamping to [0, 20].
     * @param val  New grade value.
     */
    void setNote(float val);
};

#endif
