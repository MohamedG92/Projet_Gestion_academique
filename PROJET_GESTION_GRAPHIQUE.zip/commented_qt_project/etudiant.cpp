/**
 * @file etudiant.cpp
 * @brief Implementation of the etudiant class.
 */

#include "etudiant.h"
#include <iostream>
using namespace std;

etudiant::etudiant(string cin_, string nom_, string prenom_, string cne_)
    : personne(cin_, nom_, prenom_), cne(cne_) {}

/** Frees all heap-allocated module objects. */
etudiant::~etudiant() {
    for (size_t i = 0; i < modules.size(); i++) {
        delete modules[i];
    }
}

string etudiant::getCNE() const { return cne; }
void etudiant::setCNE(string c) { cne = c; }

void etudiant::ajouterModule(module* m) {
    modules.push_back(m);
}

/** Finds the module by code, deletes it, and removes the pointer from the vector. */
void etudiant::supprimerModule(const string& codeModule) {
    for (size_t i = 0; i < modules.size(); i++) {
        if (modules[i]->code == codeModule) {
            delete modules[i];
            modules.erase(modules.begin() + i);
            cout << "Module supprime avec succes.\n";
            return;
        }
    }
    cout << "Module non trouve.\n";
}

/** Delegates to module::ajouterControle once the correct module is found. */
void etudiant::ajouterControle(const string& codeModule, controle* c) {
    for (size_t i = 0; i < modules.size(); i++) {
        if (modules[i]->code == codeModule) {
            modules[i]->ajouterControle(c);
            return;
        }
    }
    cout << "Module non trouve pour cet etudiant.\n";
}

/** Delegates to module::modifierNote once the correct module is found. */
bool etudiant::modifierNote(const string& codeModule, const string& type, float nouvelleNote) {
    for (size_t i = 0; i < modules.size(); i++) {
        if (modules[i]->code == codeModule) {
            return modules[i]->modifierNote(type, nouvelleNote);
        }
    }
    return false;
}

/**
 * Computes: Σ(moduleAvg_i × coef_i) / Σcoef_i.
 * Returns 0 when there are no modules (avoids division by zero).
 */
float etudiant::calculMoyenneGenerale() const {
    float somme = 0;
    int totalCoef = 0;
    for (size_t i = 0; i < modules.size(); i++) {
        somme += modules[i]->moyenneModule() * modules[i]->coefficient;
        totalCoef += modules[i]->coefficient;
    }
    if (totalCoef == 0) return 0;
    return somme / totalCoef;
}

/** Passing threshold is 10/20. */
string etudiant::decisionAcademique() const {
    return calculMoyenneGenerale() >= 10 ? "Admis" : "Ajourne";
}

/** Iterates all modules and returns the intitule of the one with the highest average. */
string etudiant::meilleurModule() const {
    if (modules.empty()) return "Aucun module";
    string meilleur = modules[0]->intitule;
    float maxMoy = modules[0]->moyenneModule();
    for (size_t i = 1; i < modules.size(); i++) {
        float moy = modules[i]->moyenneModule();
        if (moy > maxMoy) { maxMoy = moy; meilleur = modules[i]->intitule; }
    }
    return meilleur;
}

/** Iterates all modules and returns the intitule of the one with the lowest average. */
string etudiant::moduleFaible() const {
    if (modules.empty()) return "Aucun module";
    string faible = modules[0]->intitule;
    float minMoy = modules[0]->moyenneModule();
    for (size_t i = 1; i < modules.size(); i++) {
        float moy = modules[i]->moyenneModule();
        if (moy < minMoy) { minMoy = moy; faible = modules[i]->intitule; }
    }
    return faible;
}

/**
 * Algorithm:
 *  1. Sum contributions of all non-EXAM assessments.
 *  2. Compute: needed = (10 - contrib) / (examPct / 100).
 *  3. Return 0 if already passing, 21 if out of range (impossible), -1 if module/exam not found.
 */
float etudiant::noteNecessaire(const string& codeModule) const {
    for (size_t i = 0; i < modules.size(); i++) {
        if (modules[i]->code == codeModule) {
            float contrib = 0;
            float examPct = 0;
            for (size_t j = 0; j < modules[i]->controles.size(); j++) {
                controle* c = modules[i]->controles[j];
                if (c->getType() != "EXAM")
                    contrib += c->getNote() * c->getPourcentage() / 100.0;
                else
                    examPct = c->getPourcentage();
            }
            if (examPct == 0) return -1;  // No EXAM component found
            float needed = (10.0 - contrib) / (examPct / 100.0);
            if (needed < 0) return 0;   // Already passing without the exam
            if (needed > 20) return 21; // Impossible to reach 10 even with 20/20
            return needed;
        }
    }
    return -1;  // Module not found
}

/** Debug helper — prints all modules and assessments to stdout. */
void etudiant::afficherModules() const {
    for (size_t i = 0; i < modules.size(); i++) {
        module* m = modules[i];
        cout << "  Module: " << m->code << " - " << m->intitule
             << " | Coef: " << m->coefficient
             << " | Enseignant: " << m->codeEnseignant
             << " | Semestre: " << m->semestre << endl;
        for (size_t j = 0; j < m->controles.size(); j++) {
            controle* c = m->controles[j];
            cout << "    " << c->getType() << " (" << c->getPourcentage() << "%): " << c->getNote() << endl;
        }
        if (!m->controles.empty())
            cout << "    Moyenne module: " << m->moyenneModule() << endl;
    }
}
