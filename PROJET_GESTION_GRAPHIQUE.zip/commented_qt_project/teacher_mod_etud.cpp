/**
 * @file teacher_mod_etud.cpp
 * @brief Implementation of the "modify student" teacher dialog.
 *
 * Finds the student by their current CNE, applies non-empty field updates,
 * then calls db_save_etudiant to persist the changes.
 */

#include "teacher_mod_etud.h"
#include "ui_teacher_mod_etud.h"
#include "database.h"
#include <QMessageBox>

teacher_mod_etud::teacher_mod_etud(vector<etudiant*>* etudiants, QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::teacher_mod_etud)
    , etudiants(etudiants)
{
    ui->setupUi(this);
    connect(ui->pushButton_2, &QPushButton::clicked, this, &teacher_mod_etud::on_sauvegarder);
    connect(ui->pushButton,   &QPushButton::clicked, this, &QDialog::close);
}

teacher_mod_etud::~teacher_mod_etud() { delete ui; }

void teacher_mod_etud::on_sauvegarder()
{
    // lineEdit=ancien CNE, lineEdit_2=nouveau NOM, lineEdit_3=nouveau PRENOM, lineEdit_4=nouveau CNE
    QString ancienCne = ui->lineEdit->text().trimmed();
    QString nvNom     = ui->lineEdit_2->text().trimmed();
    QString nvPrenom  = ui->lineEdit_3->text().trimmed();
    QString nvCne     = ui->lineEdit_4->text().trimmed();

    if (ancienCne.isEmpty()) {
        QMessageBox::warning(this, "Erreur", "Entrez l'ancien CNE."); return;
    }
    etudiant* cible = nullptr;
    for (int i = 0; i < (int)etudiants->size(); i++)
        if ((*etudiants)[i]->getCNE() == ancienCne.toStdString()) { cible = (*etudiants)[i]; break; }

    if (!cible) { QMessageBox::warning(this, "Erreur", "Etudiant introuvable."); return; }

    if (!nvNom.isEmpty())    cible->setNom(nvNom.toStdString());
    if (!nvPrenom.isEmpty()) cible->setPrenom(nvPrenom.toStdString());
    if (!nvCne.isEmpty())    cible->setCNE(nvCne.toStdString());

    db_save_etudiant(cible);
    QMessageBox::information(this, "Succes", "Etudiant modifie !");
    ui->lineEdit->clear(); ui->lineEdit_2->clear();
    ui->lineEdit_3->clear(); ui->lineEdit_4->clear();
}
