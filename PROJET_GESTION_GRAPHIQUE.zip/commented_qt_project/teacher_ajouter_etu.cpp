/**
 * @file teacher_ajouter_etu.cpp
 * @brief Implementation of the "add student" teacher dialog.
 */

#include "teacher_ajouter_etu.h"
#include "ui_teacher_ajouter_etu.h"
#include "database.h"
#include <QMessageBox>

teacher_ajouter_etu::teacher_ajouter_etu(vector<etudiant*>* etudiants, QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::teacher_ajouter_etu)
    , etudiants(etudiants)
{
    ui->setupUi(this);
    connect(ui->pushButton,   &QPushButton::clicked, this, &teacher_ajouter_etu::on_sauvegarder);
    connect(ui->pushButton_2, &QPushButton::clicked, this, &QDialog::close);
}

teacher_ajouter_etu::~teacher_ajouter_etu() { delete ui; }

/**
 * Reads the four input fields (CIN, Nom, Prénom, CNE), checks for
 * empty fields and duplicate CIN/CNE, then creates and saves the new student.
 * Fields are cleared on success.
 *
 * Field mapping: lineEdit=CIN, lineEdit_2=NOM, lineEdit_3=PRENOM, lineEdit_4=CNE
 */
void teacher_ajouter_etu::on_sauvegarder()
{
    QString cin    = ui->lineEdit->text().trimmed();
    QString nom    = ui->lineEdit_2->text().trimmed();
    QString prenom = ui->lineEdit_3->text().trimmed();
    QString cne    = ui->lineEdit_4->text().trimmed();

    if (cin.isEmpty() || nom.isEmpty() || prenom.isEmpty() || cne.isEmpty()) {
        QMessageBox::warning(this, "Erreur", "Veuillez remplir tous les champs.");
        return;
    }
    // Check for duplicate CNE or CIN in the in-memory list
    for (int i = 0; i < (int)etudiants->size(); i++) {
        if ((*etudiants)[i]->getCNE() == cne.toStdString()) {
            QMessageBox::warning(this, "Erreur", "Ce CNE existe deja."); return;
        }
        if ((*etudiants)[i]->getCIN() == cin.toStdString()) {
            QMessageBox::warning(this, "Erreur", "Ce CIN existe deja."); return;
        }
    }
    etudiant* e = new etudiant(cin.toStdString(), nom.toStdString(), prenom.toStdString(), cne.toStdString());
    etudiants->push_back(e);
    db_save_etudiant(e);  // Persist immediately to the DB
    QMessageBox::information(this, "Succes", "Etudiant ajoute !");
    ui->lineEdit->clear(); ui->lineEdit_2->clear();
    ui->lineEdit_3->clear(); ui->lineEdit_4->clear();
}
