/**
 * @file teacher_stat.h
 * @brief Teacher dialog — class-level statistics.
 *
 * Computes and displays:
 *   - Pass rate (% of students with average >= 10)
 *   - Best student (highest general average)
 *   - Student in most difficulty (lowest general average)
 */

#ifndef TEACHER_STAT_H
#define TEACHER_STAT_H

#include <QDialog>
#include <vector>
#include "etudiant.h"

namespace Ui { class teacher_stat; }

class teacher_stat : public QDialog
{
    Q_OBJECT
public:
    explicit teacher_stat(vector<etudiant*>* etudiants, QWidget *parent = nullptr);
    ~teacher_stat();
private:
    Ui::teacher_stat *ui;
    vector<etudiant*>* etudiants;
};

#endif
