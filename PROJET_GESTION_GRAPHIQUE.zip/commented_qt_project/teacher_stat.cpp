/**
 * @file teacher_stat.cpp
 * @brief Implementation of the class statistics dialog.
 *
 * Iterates all students in a single pass to compute:
 *   admis count, best student name, weakest student name.
 * Pass rate = admis / total * 100.
 */

#include "teacher_stat.h"
#include "ui_teacher_stat.h"

teacher_stat::teacher_stat(vector<etudiant*>* etudiants, QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::teacher_stat)
    , etudiants(etudiants)
{
    ui->setupUi(this);
    connect(ui->pushButton,   &QPushButton::clicked, this, &QDialog::close);
    connect(ui->pushButton_2, &QPushButton::clicked, this, &QDialog::close);

    if (etudiants->empty()) {
        ui->moygen->setText("Aucun etudiant");
        ui->moygen_2->setText("N/A");
        ui->moygen_3->setText("N/A");
        return;
    }

    int admis = 0;
    float maxMoy = -1, minMoy = 21;
    string meilleur, difficulte;

    for (int i = 0; i < (int)etudiants->size(); i++) {
        etudiant* e = (*etudiants)[i];
        float moy = e->calculMoyenneGenerale();
        if (e->decisionAcademique() == "Admis") admis++;
        if (moy > maxMoy) { maxMoy = moy; meilleur  = e->getNom() + " " + e->getPrenom(); }
        if (moy < minMoy) { minMoy = moy; difficulte = e->getNom() + " " + e->getPrenom(); }
    }

    float taux = (float)admis / etudiants->size() * 100.0f;
    ui->moygen->setText(QString::number(taux, 'f', 1) + "% (" +
                        QString::number(admis) + "/" +
                        QString::number((int)etudiants->size()) + ")");
    ui->moygen_2->setText(QString::fromStdString(meilleur));
    ui->moygen_3->setText(QString::fromStdString(difficulte));
}

teacher_stat::~teacher_stat() { delete ui; }
