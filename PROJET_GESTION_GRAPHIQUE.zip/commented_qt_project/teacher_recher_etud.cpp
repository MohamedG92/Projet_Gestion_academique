/**
 * @file teacher_recher_etud.cpp
 * @brief Implementation of the student search dialog.
 *
 * Populates the table with one row per module:
 *   code, title, coefficient, teacher code, TP note, EXAM note, module average.
 * Also shows general average, decision, and best module.
 */

#include "teacher_recher_etud.h"
#include "ui_teacher_recher_etud.h"
#include <QMessageBox>
#include <QTableWidgetItem>

teacher_recher_etud::teacher_recher_etud(vector<etudiant*>* etudiants, QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::teacher_recher_etud)
    , etudiants(etudiants)
{
    ui->setupUi(this);
    connect(ui->pushButton_2, &QPushButton::clicked, this, &teacher_recher_etud::on_rechercher);
    connect(ui->pushButton,   &QPushButton::clicked, this, &QDialog::close);
    connect(ui->lineEdit, &QLineEdit::returnPressed, this, &teacher_recher_etud::on_rechercher);
}

teacher_recher_etud::~teacher_recher_etud() { delete ui; }

void teacher_recher_etud::on_rechercher()
{
    QString cne = ui->lineEdit->text().trimmed();
    if (cne.isEmpty()) { QMessageBox::warning(this, "Erreur", "Entrez un CNE."); return; }

    etudiant* e = nullptr;
    for (int i = 0; i < (int)etudiants->size(); i++)
        if ((*etudiants)[i]->getCNE() == cne.toStdString()) { e = (*etudiants)[i]; break; }

    if (!e) { QMessageBox::warning(this, "Erreur", "Etudiant introuvable."); return; }

    ui->moygen->setText(QString::number(e->calculMoyenneGenerale(), 'f', 2));
    ui->statut->setText(QString::fromStdString(e->decisionAcademique()));
    ui->meilleumatiere->setText(QString::fromStdString(e->meilleurModule()));

    ui->tableWidget->setRowCount((int)e->modules.size());
    for (int i = 0; i < (int)e->modules.size(); i++) {
        module* m = e->modules[i];
        float tp = 0, exam = 0;
        for (int j = 0; j < (int)m->controles.size(); j++) {
            if (m->controles[j]->getType() == "TP")   tp   = m->controles[j]->getNote();
            if (m->controles[j]->getType() == "EXAM") exam = m->controles[j]->getNote();
        }
        ui->tableWidget->setItem(i, 0, new QTableWidgetItem(QString::fromStdString(m->code)));
        ui->tableWidget->setItem(i, 1, new QTableWidgetItem(QString::fromStdString(m->intitule)));
        ui->tableWidget->setItem(i, 2, new QTableWidgetItem(QString::number(m->coefficient)));
        ui->tableWidget->setItem(i, 3, new QTableWidgetItem(QString::fromStdString(m->codeEnseignant)));
        ui->tableWidget->setItem(i, 4, new QTableWidgetItem(QString::number(tp,   'f', 2)));
        ui->tableWidget->setItem(i, 5, new QTableWidgetItem(QString::number(exam, 'f', 2)));
        ui->tableWidget->setItem(i, 6, new QTableWidgetItem(QString::number(m->moyenneModule(), 'f', 2)));
    }
    ui->tableWidget->resizeColumnsToContents();
}
