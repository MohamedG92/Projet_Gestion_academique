/**
 * @file etudiant.h
 * @brief Student class — extends personne, owns a list of modules and computes academic stats.
 *
 * Key responsibilities:
 *  - CRUD on the student's module list
 *  - General average and academic decision (Admis / Ajourné)
 *  - Per-module "note nécessaire" to pass the EXAM component
 */

#ifndef ETUDIANT_H
#define ETUDIANT_H

#include <string>
#include <vector>
#include "personne.h"
#include "module.h"
#include "controle.h"
using namespace std;

/**
 * @class etudiant
 * @brief A student with a CNE identifier and a list of enrolled modules.
 *
 * Inherits CIN, nom, and prenom from personne.
 * The modules vector is public for direct iteration in the UI layer.
 * The destructor frees all owned module pointers.
 */
class etudiant : public personne {
private:
    string cne;  ///< Student registration number (CNE — Code National de l'Étudiant)

public:
    vector<module*> modules;  ///< All modules enrolled by this student

    /**
     * @brief Constructs an etudiant.
     * @param cin_    National ID.
     * @param nom_    Last name.
     * @param prenom_ First name.
     * @param cne_    Student CNE (used as login identifier).
     */
    etudiant(string cin_, string nom_, string prenom_, string cne_);

    /** @brief Destructor — deletes all owned module pointers. */
    ~etudiant();

    /** @brief Returns the CNE. */
    string getCNE() const;

    /** @brief Updates the CNE. */
    void setCNE(string c);

    /**
     * @brief Appends a module to the student's list.
     * @param m  Heap-allocated module (ownership transferred).
     */
    void ajouterModule(module* m);

    /**
     * @brief Removes and deletes the module matching codeModule.
     * Prints a message if the module is not found.
     */
    void supprimerModule(const string& codeModule);

    /**
     * @brief Adds an assessment to an existing module.
     * @param codeModule  Target module code.
     * @param c           Heap-allocated controle (ownership transferred to the module).
     */
    void ajouterControle(const string& codeModule, controle* c);

    /**
     * @brief Updates a grade inside a specific module.
     * @param codeModule   Target module code.
     * @param type         Assessment type ("TP", "CC", or "EXAM").
     * @param nouvelleNote New grade (0-20).
     * @return true if the update succeeded, false if module/type not found.
     */
    bool modifierNote(const string& codeModule, const string& type, float nouvelleNote);

    /**
     * @brief Computes the coefficient-weighted average across all modules.
     * @return General average on a 0-20 scale (0 if no modules).
     */
    float calculMoyenneGenerale() const;

    /**
     * @brief Returns "Admis" if average ≥ 10, "Ajourné" otherwise.
     */
    string decisionAcademique() const;

    /** @brief Returns the name of the module with the highest average. */
    string meilleurModule() const;

    /** @brief Returns the name of the module with the lowest average. */
    string moduleFaible() const;

    /**
     * @brief Calculates the EXAM grade needed to reach the passing threshold (10/20).
     *
     * Uses: needed = (10 - contrib_non_exam) / (examPct / 100).
     * @param codeModule  Target module code.
     * @return Needed grade, 0 if already passing, 21 if impossible, -1 if not found.
     */
    float noteNecessaire(const string& codeModule) const;

    /** @brief Prints all modules and their assessments to stdout (debug helper). */
    void afficherModules() const;
};

#endif
