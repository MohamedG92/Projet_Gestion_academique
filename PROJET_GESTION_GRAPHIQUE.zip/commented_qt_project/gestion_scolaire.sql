-- ─────────────────────────────────────────────────────────
--  gestion_scolaire.sql
--  Run this ONCE in MySQL/MariaDB to create the database
--  mysql -u root -p < gestion_scolaire.sql
-- ─────────────────────────────────────────────────────────

CREATE DATABASE IF NOT EXISTS gestion_scolaire;
USE gestion_scolaire;

-- Enseignants
CREATE TABLE IF NOT EXISTS enseignants (
    cin              VARCHAR(20) PRIMARY KEY,
    nom              VARCHAR(100) NOT NULL,
    prenom           VARCHAR(100) NOT NULL,
    code_enseignant  VARCHAR(20) UNIQUE NOT NULL
);

-- Etudiants
CREATE TABLE IF NOT EXISTS etudiants (
    cin    VARCHAR(20) PRIMARY KEY,
    nom    VARCHAR(100) NOT NULL,
    prenom VARCHAR(100) NOT NULL,
    cne    VARCHAR(20) UNIQUE NOT NULL
);

-- Modules (each module belongs to one student)
CREATE TABLE IF NOT EXISTS modules (
    code             VARCHAR(20) PRIMARY KEY,
    intitule         VARCHAR(200) NOT NULL,
    coefficient      INT NOT NULL DEFAULT 1,
    code_enseignant  VARCHAR(20),
    semestre         INT NOT NULL DEFAULT 1,
    cne_etudiant     VARCHAR(20) NOT NULL,
    FOREIGN KEY (cne_etudiant) REFERENCES etudiants(cne) ON DELETE CASCADE,
    FOREIGN KEY (code_enseignant) REFERENCES enseignants(code_enseignant) ON DELETE SET NULL
);

-- Controles (each controle belongs to one module)
CREATE TABLE IF NOT EXISTS controles (
    id           INT AUTO_INCREMENT PRIMARY KEY,
    type         VARCHAR(50) NOT NULL,   -- e.g. "EXAM", "DS", "TP"
    pourcentage  FLOAT NOT NULL,         -- e.g. 60.0 for 60%
    note         FLOAT NOT NULL DEFAULT 0,
    code_module  VARCHAR(20) NOT NULL,
    FOREIGN KEY (code_module) REFERENCES modules(code) ON DELETE CASCADE
);

-- ── Sample data (optional) ────────────────────────────────────
INSERT IGNORE INTO enseignants VALUES ('C001','Alaoui','Mohammed','ENS001');
INSERT IGNORE INTO enseignants VALUES ('C002','Benali','Fatima','ENS002');

INSERT IGNORE INTO etudiants VALUES ('CI001','Idrissi','Youssef','CNE001');
INSERT IGNORE INTO etudiants VALUES ('CI002','Zouheir','Amal','CNE002');

INSERT IGNORE INTO modules VALUES ('MOD001','Algorithmique',3,'ENS001',1,'CNE001');
INSERT IGNORE INTO modules VALUES ('MOD002','Mathematiques',4,'ENS002',1,'CNE001');

INSERT IGNORE INTO controles (type, pourcentage, note, code_module)
VALUES ('DS',40,14,'MOD001'),('EXAM',60,12,'MOD001');

INSERT IGNORE INTO controles (type, pourcentage, note, code_module)
VALUES ('DS',40,10,'MOD002'),('EXAM',60,8,'MOD002');
