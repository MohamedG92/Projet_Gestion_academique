/**
 * @file note.cpp
 * @brief Implementation of the note class.
 */

#include "note.h"

note::note(float val) : n(val) {}

/** Prompts the user and clamps the entered value to [0, 20]. */
void note::saisir() {
    cout << "Note (0-20) : ";
    cin >> n;
    if (n < 0) n = 0;
    if (n > 20) n = 20;
}

void note::afficher() const {
    cout << n;
}

float note::getNote() const { return n; }

/** Clamps val to [0, 20] before storing. */
void note::setNote(float val) {
    if (val < 0) val = 0;
    if (val > 20) val = 20;
    n = val;
}
