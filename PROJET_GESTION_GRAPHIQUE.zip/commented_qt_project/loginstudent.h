/**
 * @file loginstudent.h
 * @brief Student login dialog — authenticates by CNE only (no password).
 *
 * On successful login, opens the studentstat dialog showing the
 * student's grades, averages, and academic decision.
 */

#ifndef LOGINSTUDENT_H
#define LOGINSTUDENT_H

#include <QDialog>
#include <vector>
#include "etudiant.h"

namespace Ui { class loginstudent; }

/**
 * @class loginstudent
 * @brief Dialog for student authentication by CNE.
 *
 * Holds a non-owning pointer to the master student list.
 * etudiantConnecte is set to the found student on successful login.
 */
class loginstudent : public QDialog
{
    Q_OBJECT

public:
    /**
     * @brief Constructs the student login dialog.
     * @param etudiants  Non-owning pointer to the master student list.
     * @param parent     Parent widget.
     */
    explicit loginstudent(vector<etudiant*>* etudiants, QWidget *parent = nullptr);
    ~loginstudent();

private slots:
    void on_pushButton_clicked();    ///< "Connexion" — finds the student by CNE and opens their stats
    void on_pushButton_2_clicked();  ///< "Retour" — closes the dialog

private:
    Ui::loginstudent *ui;
    vector<etudiant*>* etudiants;       ///< Non-owning pointer to the master student list
    etudiant* etudiantConnecte;         ///< Points to the logged-in student (nullptr if not yet logged in)
};

#endif // LOGINSTUDENT_H
