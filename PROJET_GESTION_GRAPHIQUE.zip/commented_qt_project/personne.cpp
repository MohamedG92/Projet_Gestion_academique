/**
 * @file personne.cpp
 * @brief Implementation of the personne base class.
 */

#include "personne.h"

/** Initialises all three fields via member-initialiser list. */
personne::personne(string c, string n, string p): cin(c), nom(n), prenom(p) {}

string personne::getCIN() const { return cin; }
string personne::getNom() const { return nom; }
string personne::getPrenom() const { return prenom; }

void personne::setNom(string n) { nom = n; }
void personne::setPrenom(string p) { prenom = p; }
