/**
 * @file database.cpp
 * @brief Implementation of the Qt SQL database layer.
 *
 * Two inline helpers avoid repetitive Qt↔std string conversions:
 *   qs() — QString  → std::string
 *   sq() — std::string → QString
 */

#include "database.h"

/** Converts a QString to a std::string. */
static string qs(const QString& s) { return s.toStdString(); }

/** Converts a std::string to a QString. */
static QString sq(const string& s)  { return QString::fromStdString(s); }

// ─────────────────────────────────────────────────────────────
//  CONNECTION
// ─────────────────────────────────────────────────────────────

/**
 * Opens an ODBC connection to the local MariaDB instance.
 * The connection string targets the "khdaminshalah" database on localhost:3306.
 * Returns false and logs an error if the connection fails.
 */
bool db_connect()
{
    QSqlDatabase db = QSqlDatabase::addDatabase("QODBC");
    db.setDatabaseName("DRIVER={MySQL ODBC 9.6 Unicode Driver};"
                       "SERVER=localhost;"
                       "DATABASE=khdaminshalah;"
                       "USER=root;"
                       "PASSWORD=;"
                       "PORT=3306;");

    if (!db.open()) {
        qDebug() << "DB connection failed:" << db.lastError().text();
        return false;
    }
    qDebug() << "DB connected successfully";
    return true;
}

void db_disconnect()
{
    QSqlDatabase::database().close();
}

// ─────────────────────────────────────────────────────────────
//  ETUDIANTS
// ─────────────────────────────────────────────────────────────

/**
 * Reloads the entire etudiants list from the database.
 *
 * Nested query strategy:
 *   1. SELECT all rows from etudiants.
 *   2. For each student, SELECT their modules (filtered by etudiant_cin).
 *   3. For each module, SELECT its controles (filtered by module_id).
 *
 * All previously allocated objects in the vector are deleted before loading.
 */
void db_load_etudiants(vector<etudiant*>& etudiants)
{
    // Free existing objects to avoid memory leaks
    for (int i = 0; i < (int)etudiants.size(); i++)
        delete etudiants[i];
    etudiants.clear();

    QSqlQuery q("SELECT cin, nom, prenom, cne FROM etudiants");
    while (q.next()) {
        etudiant* e = new etudiant(
            qs(q.value(0).toString()),   // cin
            qs(q.value(1).toString()),   // nom
            qs(q.value(2).toString()),   // prenom
            qs(q.value(3).toString())    // cne
            );

        // Load this student's modules
        QSqlQuery qm;
        qm.prepare("SELECT id, code, intitule, coefficient, codeEnseignant, semestre "
                   "FROM modules WHERE etudiant_cin = ?");
        qm.addBindValue(q.value(0));   // bind cin
        qm.exec();

        while (qm.next()) {
            int moduleId = qm.value(0).toInt();

            module* m = new module(
                qs(qm.value(1).toString()),   // code
                qs(qm.value(2).toString()),   // intitule
                qm.value(3).toInt(),           // coefficient
                qs(qm.value(4).toString()),   // codeEnseignant
                qm.value(5).toInt()            // semestre
                );

            // Load this module's assessments
            QSqlQuery qc;
            qc.prepare("SELECT type, pourcentage, note "
                       "FROM controles WHERE module_id = ?");
            qc.addBindValue(moduleId);
            qc.exec();

            while (qc.next()) {
                controle* c = new controle(
                    qs(qc.value(0).toString()),  // type
                    qc.value(1).toFloat(),        // pourcentage
                    qc.value(2).toFloat()         // note
                    );
                m->ajouterControle(c);
            }

            e->ajouterModule(m);
        }

        etudiants.push_back(e);
    }
}

/**
 * Upserts a student and all their modules/assessments.
 *
 * For each module, the DB-assigned id is fetched via a SELECT after the
 * module upsert so the controles can reference it with the correct foreign key.
 */
void db_save_etudiant(etudiant* e)
{
    // Upsert the student row
    QSqlQuery q;
    q.prepare("INSERT INTO etudiants (cin, nom, prenom, cne) VALUES (?,?,?,?) "
              "ON DUPLICATE KEY UPDATE nom=VALUES(nom), prenom=VALUES(prenom), cne=VALUES(cne)");
    q.addBindValue(sq(e->getCIN()));
    q.addBindValue(sq(e->getNom()));
    q.addBindValue(sq(e->getPrenom()));
    q.addBindValue(sq(e->getCNE()));
    if (!q.exec())
        qDebug() << "Save etudiant failed:" << q.lastError().text();

    for (int i = 0; i < (int)e->modules.size(); i++) {
        module* m = e->modules[i];

        // Upsert the module row
        QSqlQuery qm;
        qm.prepare("INSERT INTO modules (code, intitule, coefficient, codeEnseignant, semestre, etudiant_cin) "
                   "VALUES (?,?,?,?,?,?) "
                   "ON DUPLICATE KEY UPDATE intitule=VALUES(intitule), coefficient=VALUES(coefficient)");
        qm.addBindValue(sq(m->code));
        qm.addBindValue(sq(m->intitule));
        qm.addBindValue(m->coefficient);
        qm.addBindValue(sq(m->codeEnseignant));
        qm.addBindValue(m->semestre);
        qm.addBindValue(sq(e->getCIN()));
        if (!qm.exec()) {
            qDebug() << "Save module failed:" << qm.lastError().text();
            continue;
        }

        // Retrieve the auto-generated module ID needed for controles FK
        QSqlQuery qid;
        qid.prepare("SELECT id FROM modules WHERE etudiant_cin=? AND code=?");
        qid.addBindValue(sq(e->getCIN()));
        qid.addBindValue(sq(m->code));
        int moduleId = -1;
        if (qid.exec() && qid.next())
            moduleId = qid.value(0).toInt();

        // Upsert each assessment for this module
        for (int j = 0; j < (int)m->controles.size(); j++) {
            controle* c = m->controles[j];
            QSqlQuery qc;
            qc.prepare("INSERT INTO controles (type, pourcentage, note, module_id) "
                       "VALUES (?,?,?,?) "
                       "ON DUPLICATE KEY UPDATE note=VALUES(note), pourcentage=VALUES(pourcentage)");
            qc.addBindValue(sq(c->getType()));
            qc.addBindValue(c->getPourcentage());
            qc.addBindValue(c->getNote());
            qc.addBindValue(moduleId);
            if (!qc.exec())
                qDebug() << "Save controle failed:" << qc.lastError().text();
        }
    }
}

/**
 * Deletes the student identified by CNE.
 * Cascade delete in the DB removes their modules and controles automatically.
 */
void db_delete_etudiant(const string& cne)
{
    QSqlQuery q;
    q.prepare("DELETE FROM etudiants WHERE cne = ?");
    q.addBindValue(sq(cne));
    if (!q.exec())
        qDebug() << "Delete etudiant failed:" << q.lastError().text();
}

/** Saves every student in the vector by calling db_save_etudiant in a loop. */
void db_save_all_etudiants(vector<etudiant*>& etudiants)
{
    for (int i = 0; i < (int)etudiants.size(); i++)
        db_save_etudiant(etudiants[i]);
}

// ─────────────────────────────────────────────────────────────
//  ENSEIGNANTS
// ─────────────────────────────────────────────────────────────

/**
 * Reloads the enseignants list from the database.
 * Frees existing objects before loading to avoid memory leaks.
 */
void db_load_enseignants(vector<enseignant*>& enseignants)
{
    for (int i = 0; i < (int)enseignants.size(); i++)
        delete enseignants[i];
    enseignants.clear();

    QSqlQuery q("SELECT cin, nom, prenom, code FROM enseignants");
    while (q.next()) {
        enseignant* e = new enseignant(
            qs(q.value(0).toString()),  // cin
            qs(q.value(1).toString()),  // nom
            qs(q.value(2).toString()),  // prenom
            qs(q.value(3).toString())   // code
            );
        enseignants.push_back(e);
    }
}

/** Upserts a teacher row (updates nom/prenom on duplicate CIN). */
void db_save_enseignant(enseignant* e)
{
    QSqlQuery q;
    q.prepare("INSERT INTO enseignants (cin, nom, prenom, code) VALUES (?,?,?,?) "
              "ON DUPLICATE KEY UPDATE nom=VALUES(nom), prenom=VALUES(prenom)");
    q.addBindValue(sq(e->getCIN()));
    q.addBindValue(sq(e->getNom()));
    q.addBindValue(sq(e->getPrenom()));
    q.addBindValue(sq(e->getCode()));
    if (!q.exec())
        qDebug() << "Save enseignant failed:" << q.lastError().text();
}
