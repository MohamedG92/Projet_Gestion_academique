/**
 * @file database.h
 * @brief Qt SQL database layer — connection and CRUD operations for etudiants and enseignants.
 *
 * Uses Qt's ODBC driver to connect to a local MariaDB/MySQL instance (via XAMPP).
 * All functions are free (non-member) to keep the model classes independent of Qt.
 *
 * Connection string targets:
 *   Driver  : MySQL ODBC 9.6 Unicode Driver
 *   Server  : localhost (127.0.0.1)
 *   Database: khdaminshalah
 *   User    : root  |  Password: (empty)  |  Port: 3306
 */

#ifndef DATABASE_H
#define DATABASE_H

#include <QtSql/QSqlDatabase>
#include <QtSql/QSqlQuery>
#include <QtSql/QSqlError>
#include <QDebug>
#include <vector>
#include <string>
#include "etudiant.h"
#include "enseignant.h"

using namespace std;

// ─── Connection ──────────────────────────────────────────────────────────────

/** @brief Opens the ODBC connection. Returns true on success. */
bool db_connect();

/** @brief Closes the database connection. */
void db_disconnect();

// ─── Etudiants ───────────────────────────────────────────────────────────────

/**
 * @brief Clears and reloads the etudiants vector from the database.
 *
 * For each student, recursively loads their modules and assessments
 * via two nested queries (modules → controles).
 * Any previously allocated objects in the vector are deleted first.
 *
 * @param etudiants  Output vector; owned objects are replaced.
 */
void db_load_etudiants(vector<etudiant*>& etudiants);

/**
 * @brief Inserts or updates a student and all their modules/assessments.
 *
 * Uses INSERT … ON DUPLICATE KEY UPDATE for upsert semantics.
 * Retrieves the generated module ID before saving its controles.
 *
 * @param e  Student to persist.
 */
void db_save_etudiant(etudiant* e);

/**
 * @brief Deletes a student record (and cascades to modules/controles) by CNE.
 * @param cne  Student CNE.
 */
void db_delete_etudiant(const string& cne);

/**
 * @brief Saves every student in the vector (calls db_save_etudiant in a loop).
 * @param etudiants  Vector of students to persist.
 */
void db_save_all_etudiants(vector<etudiant*>& etudiants);

// ─── Enseignants ─────────────────────────────────────────────────────────────

/**
 * @brief Clears and reloads the enseignants vector from the database.
 * @param enseignants  Output vector; owned objects are replaced.
 */
void db_load_enseignants(vector<enseignant*>& enseignants);

/**
 * @brief Inserts or updates a teacher record.
 * @param e  Teacher to persist.
 */
void db_save_enseignant(enseignant* e);

#endif // DATABASE_H
