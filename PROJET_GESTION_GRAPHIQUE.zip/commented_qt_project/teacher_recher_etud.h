/**
 * @file teacher_recher_etud.h
 * @brief Teacher dialog — search for a student and view their stats.
 *
 * Looks up a student by CNE and displays their modules, grades,
 * average, decision, and best module in a table.
 */

#ifndef TEACHER_RECHER_ETUD_H
#define TEACHER_RECHER_ETUD_H

#include <QDialog>
#include <vector>
#include "etudiant.h"

namespace Ui { class teacher_recher_etud; }

class teacher_recher_etud : public QDialog
{
    Q_OBJECT
public:
    explicit teacher_recher_etud(vector<etudiant*>* etudiants, QWidget *parent = nullptr);
    ~teacher_recher_etud();
private slots:
    void on_rechercher();
private:
    Ui::teacher_recher_etud *ui;
    vector<etudiant*>* etudiants;
};

#endif
