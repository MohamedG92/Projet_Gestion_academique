/**
 * @file teacher_affich_tout_etud.h
 * @brief Teacher dialog — display all students in a table.
 *
 * Shows CNE, CIN, Nom, and Prénom for every student in the system.
 * Read-only; no editing is possible from this dialog.
 */

#ifndef TEACHER_AFFICH_TOUT_ETUD_H
#define TEACHER_AFFICH_TOUT_ETUD_H

#include <QDialog>
#include <vector>
#include "etudiant.h"

namespace Ui { class teacher_affich_tout_etud; }

class teacher_affich_tout_etud : public QDialog
{
    Q_OBJECT
public:
    explicit teacher_affich_tout_etud(vector<etudiant*>* etudiants, QWidget *parent = nullptr);
    ~teacher_affich_tout_etud();
private:
    Ui::teacher_affich_tout_etud *ui;
    vector<etudiant*>* etudiants;
};

#endif
