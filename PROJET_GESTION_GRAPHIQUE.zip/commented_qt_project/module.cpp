/**
 * @file module.cpp
 * @brief Implementation of the module class.
 */

#include "module.h"

module::module(string c, string i, int coef, string ens, int sem)
    : code(c), intitule(i), coefficient(coef), codeEnseignant(ens), semestre(sem) {}

/** Deletes every controle pointer in the vector. */
module::~module() {
    for (size_t i = 0; i < controles.size(); i++) {
        delete controles[i];
    }
}

void module::ajouterControle(controle* c) {
    controles.push_back(c);
}

/**
 * Iterates through controles looking for a matching type.
 * Returns false if no match is found.
 */
bool module::modifierNote(const string& type, float nouvelleNote) {
    for (size_t i = 0; i < controles.size(); i++) {
        if (controles[i]->getType() == type) {
            controles[i]->setNote(nouvelleNote);
            return true;
        }
    }
    return false;
}

/**
 * Computes: Σ (grade_i × weight_i / 100).
 * Returns 0 if there are no assessments.
 */
float module::moyenneModule() const {
    float somme = 0;
    for (size_t i = 0; i < controles.size(); i++) {
        somme += controles[i]->getNote() * controles[i]->getPourcentage() / 100.0;
    }
    return somme;
}
