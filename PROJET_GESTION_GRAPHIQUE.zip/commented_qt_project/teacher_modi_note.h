/**
 * @file teacher_modi_note.h
 * @brief Teacher dialog — update the grade of an existing assessment.
 *
 * Input: CNE, module code, type (TP/CC/EXAM), new grade.
 * Delegates to etudiant::modifierNote then saves to DB.
 */

#ifndef TEACHER_MODI_NOTE_H
#define TEACHER_MODI_NOTE_H

#include <QDialog>
#include <vector>
#include "etudiant.h"

namespace Ui { class teacher_modi_note; }

class teacher_modi_note : public QDialog
{
    Q_OBJECT
public:
    explicit teacher_modi_note(vector<etudiant*>* etudiants, QWidget *parent = nullptr);
    ~teacher_modi_note();
private slots:
    void on_sauvegarder();
private:
    Ui::teacher_modi_note *ui;
    vector<etudiant*>* etudiants;
};

#endif
