/**
 * @file teacher_mod_etud.h
 * @brief Teacher dialog — edit a student identity fields.
 *
 * Input: old CNE (to locate the student), then optional new Nom/Prenom/CNE.
 * Only non-empty fields are updated.
 */

#ifndef TEACHER_MOD_ETUD_H
#define TEACHER_MOD_ETUD_H

#include <QDialog>
#include <vector>
#include "etudiant.h"

namespace Ui { class teacher_mod_etud; }

class teacher_mod_etud : public QDialog
{
    Q_OBJECT
public:
    explicit teacher_mod_etud(vector<etudiant*>* etudiants, QWidget *parent = nullptr);
    ~teacher_mod_etud();
private slots:
    void on_sauvegarder();
private:
    Ui::teacher_mod_etud *ui;
    vector<etudiant*>* etudiants;
};

#endif
