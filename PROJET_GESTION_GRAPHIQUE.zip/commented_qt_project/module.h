/**
 * @file module.h
 * @brief Represents an academic course module with its assessments.
 *
 * A module belongs to one student (stored via foreign key in the DB) and
 * holds a list of controle objects whose weighted average gives the module grade.
 */

#ifndef MODULE_H
#define MODULE_H

#include <string>
#include <vector>
#include "controle.h"
using namespace std;

/**
 * @class module
 * @brief One course within a student's curriculum.
 *
 * Public fields are used directly for convenience throughout the UI layer.
 * The destructor deletes all owned controle pointers.
 */
class module {
public:
    string code;            ///< Short course code (e.g. "INF201")
    string intitule;        ///< Full course title
    int coefficient;        ///< Weight in the overall GPA calculation
    string codeEnseignant;  ///< Teacher code who owns this module
    int semestre;           ///< Semester number (1 or 2)
    vector<controle*> controles;  ///< Assessment components (TP, CC, EXAM)

    /**
     * @brief Constructs a module with its metadata.
     * @param c    Course code.
     * @param i    Course title.
     * @param coef Coefficient / credit weight.
     * @param ens  Teacher code.
     * @param sem  Semester number.
     */
    module(string c, string i, int coef, string ens, int sem);

    /** @brief Destructor — deletes all owned controle objects. */
    ~module();

    /**
     * @brief Adds an assessment component to this module.
     * @param c  Heap-allocated controle (ownership transferred).
     */
    void ajouterControle(controle* c);

    /**
     * @brief Updates the grade of an existing assessment by type.
     * @param type          "TP", "CC", or "EXAM".
     * @param nouvelleNote  New grade value (0-20).
     * @return true if the type was found and updated, false otherwise.
     */
    bool modifierNote(const string& type, float nouvelleNote);

    /**
     * @brief Computes the weighted average of all assessments.
     *        Formula: Σ (note × pourcentage / 100).
     * @return Module average on a 0-20 scale.
     */
    float moyenneModule() const;
};

#endif
