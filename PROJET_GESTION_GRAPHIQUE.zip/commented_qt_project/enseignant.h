/**
 * @file enseignant.h
 * @brief Teacher class — extends personne with a unique teacher code.
 *
 * The teacher code is used as the login username in the application.
 * The default password for all teachers is "Admin".
 */

#ifndef ENSEIGNANT_H
#define ENSEIGNANT_H

#include "personne.h"
#include <string>
using namespace std;

/**
 * @class enseignant
 * @brief A teacher who can manage students, modules, and grades.
 *
 * Inherits CIN, nom, and prenom from personne.
 * The teacher logs in with their code + password "Admin".
 */
class enseignant : public personne {
    string codeEnseignant;  ///< Unique teacher code used as login username

public:
    /**
     * @brief Constructs an enseignant.
     * @param cin_    National ID.
     * @param nom_    Last name.
     * @param prenom_ First name.
     * @param code    Unique teacher code (login username).
     */
    enseignant(string cin_, string nom_, string prenom_, string code);

    /** @brief Returns the teacher's unique code. */
    string getCode() const;
};

#endif
