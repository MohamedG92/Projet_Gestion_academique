/**
 * @file mainwindow.cpp
 * @brief Implementation of the MainWindow class.
 */

#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "dialog.h"
#include "loginstudent.h"
#include "database.h"

/** Loads all students and teachers from the database on startup. */
MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    // Load all data from DB when app starts
    db_load_etudiants(etudiants);
    db_load_enseignants(enseignants);
}

/**
 * Saves all student data back to the DB, then frees all heap-allocated objects.
 * Teachers are read-only in the UI, so only students need saving.
 */
MainWindow::~MainWindow()
{
    // Save everything back to DB before closing
    db_save_all_etudiants(etudiants);

    // Free memory
    for (int i = 0; i < (int)etudiants.size(); i++)
        delete etudiants[i];
    for (int i = 0; i < (int)enseignants.size(); i++)
        delete enseignants[i];

    delete ui;
}

/** Hides the main window, opens the teacher login dialog, then shows it again on return. */
void MainWindow::on_pushButton_clicked()
{
    // Open teacher login, pass the shared data lists
    Dialog teacherLogin(&etudiants, &enseignants);
    this->hide();
    teacherLogin.setModal(true);
    teacherLogin.exec();
    this->show();
}

/** Hides the main window, opens the student login dialog, then shows it again on return. */
void MainWindow::on_pushButton_2_clicked()
{
    // Open student login, pass the shared data lists
    loginstudent studentLogin(&etudiants);
    this->hide();
    studentLogin.setModal(true);
    studentLogin.exec();
    this->show();
}
