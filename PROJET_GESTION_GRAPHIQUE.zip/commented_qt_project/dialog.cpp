/**
 * @file dialog.cpp
 * @brief Implementation of the teacher login and action-dispatch dialog.
 */

#include "dialog.h"
#include "ui_dialog.h"
#include "teacher_ajouter_etu.h"
#include "teacher_suppr_module.h"
#include "teacher_mod_etud.h"
#include "teacher_recher_etud.h"
#include "teacher_ajout_control_module.h"
#include "teacher_modi_note.h"
#include "teacher_affich_tout_etud.h"
#include "teacher_stat.h"
#include <QMessageBox>
#include <QtSql/QSqlQuery>

/** Sets up the UI and masks the password field. */
Dialog::Dialog(vector<etudiant*>* etudiants,
               vector<enseignant*>* enseignants,
               QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::Dialog)
    , etudiants(etudiants)
    , enseignants(enseignants)
{
    ui->setupUi(this);
    ui->lineEdit_2->setEchoMode(QLineEdit::Password);  // Hide password characters
}

Dialog::~Dialog()
{
    delete ui;
}

/**
 * Validates the entered credentials using two checks in order:
 *  1. Hard-coded admin account (username "admin" / password "admin").
 *  2. Any teacher in the DB whose code matches the username + password "Admin".
 *
 * On success, opens a QMessageBox action menu and dispatches to the
 * appropriate teacher dialog based on the clicked button.
 */
void Dialog::on_pushButton_clicked()
{
    QString idSaisi  = ui->lineEdit->text().trimmed();
    QString mdpSaisi = ui->lineEdit_2->text().trimmed();

    // Check 1: hard-coded admin account
    bool ok = (idSaisi == "admin" && mdpSaisi == "admin");

    // Check 2: any teacher from the DB — code = username, password must be "Admin"
    if (!ok) {
        QSqlQuery q;
        q.prepare("SELECT cin FROM enseignants WHERE code = :code");
        q.bindValue(":code", idSaisi);
        ok = (mdpSaisi == "Admin") && q.exec() && q.next();
    }

    if (!ok) {
        QMessageBox::warning(this, "Erreur", "ID ou mot de passe incorrect !");
        ui->lineEdit->clear();
        ui->lineEdit_2->clear();
        return;
    }

    // Build the action-selection popup menu
    QMessageBox menu(this);
    menu.setWindowTitle("Menu Professeur");
    menu.setText("Choisissez une action :");

    QPushButton* btnAjouter   = menu.addButton("Ajouter etudiant",       QMessageBox::ActionRole);
    QPushButton* btnSupprimer = menu.addButton("Supprimer module",        QMessageBox::ActionRole);
    QPushButton* btnModifier  = menu.addButton("Modifier etudiant",       QMessageBox::ActionRole);
    QPushButton* btnRecherche = menu.addButton("Rechercher etudiant",     QMessageBox::ActionRole);
    QPushButton* btnAjoutCtrl = menu.addButton("Ajouter controle",        QMessageBox::ActionRole);
    QPushButton* btnNote      = menu.addButton("Modifier note",           QMessageBox::ActionRole);
    QPushButton* btnAfficher  = menu.addButton("Afficher tous etudiants", QMessageBox::ActionRole);
    QPushButton* btnStats     = menu.addButton("Statistiques",            QMessageBox::ActionRole);
    menu.addButton("Fermer", QMessageBox::RejectRole);

    menu.exec();

    // Dispatch to the appropriate teacher dialog
    QAbstractButton* clicked = menu.clickedButton();

    if (clicked == btnAjouter) {
        teacher_ajouter_etu w(etudiants, this);
        w.exec();
    } else if (clicked == btnSupprimer) {
        teacher_suppr_module w(etudiants, this);
        w.exec();
    } else if (clicked == btnModifier) {
        teacher_mod_etud w(etudiants, this);
        w.exec();
    } else if (clicked == btnRecherche) {
        teacher_recher_etud w(etudiants, this);
        w.exec();
    } else if (clicked == btnAjoutCtrl) {
        teacher_ajout_control_module w(etudiants, this);
        w.exec();
    } else if (clicked == btnNote) {
        teacher_modi_note w(etudiants, this);
        w.exec();
    } else if (clicked == btnAfficher) {
        teacher_affich_tout_etud w(etudiants, this);
        w.exec();
    } else if (clicked == btnStats) {
        teacher_stat w(etudiants, this);
        w.exec();
    }
}

void Dialog::on_pushButton_2_clicked()
{
    this->close();
}
