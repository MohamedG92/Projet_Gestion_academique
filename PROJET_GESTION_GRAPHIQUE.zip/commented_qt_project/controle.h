/**
 * @file controle.h
 * @brief Represents one assessment component (TP, CC, or EXAM) with its weight and grade.
 *
 * Standard weights used across the system:
 *   - TP   → 20 %
 *   - CC   → 30 %
 *   - EXAM → 50 %
 */

#ifndef CONTROLE_H
#define CONTROLE_H

#include "note.h"
#include <string>
using namespace std;

/**
 * @class controle
 * @brief One graded assessment inside a module.
 *
 * Owns a heap-allocated note object; destructor frees it.
 */
class controle {
    string type;        ///< Assessment type: "TP", "CC", or "EXAM"
    float pourcentage;  ///< Weight in the module average (e.g. 50.0 for EXAM)
    note* n;            ///< Heap-allocated grade value

public:
    /**
     * @brief Constructs a controle.
     * @param t    Type string ("TP", "CC", or "EXAM").
     * @param p    Weight percentage (0-100).
     * @param val  Initial grade value (0-20).
     */
    controle(string t, float p, float val);

    /** @brief Destructor — deletes the owned note object. */
    ~controle();

    /** @brief Returns the numeric grade. */
    float getNote() const;

    /** @brief Returns the weight percentage. */
    float getPourcentage() const;

    /** @brief Returns the type string. */
    string getType() const;

    /** @brief Updates the grade (clamped to [0, 20] by note::setNote). */
    void setNote(float val);
};

#endif
