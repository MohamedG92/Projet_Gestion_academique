/**
 * @file personne.h
 * @brief Base class representing a person (student or teacher).
 *
 * Contains the common identity fields shared by both etudiant and enseignant:
 * the national ID (CIN), last name (nom), and first name (prenom).
 */

#ifndef PERSONNE_H
#define PERSONNE_H

#include <string>
using namespace std;

/**
 * @class personne
 * @brief Abstract base for all persons in the system.
 *
 * Both etudiant and enseignant inherit from this class.
 * CIN cannot be changed after construction (no setter).
 */
class personne {
protected:
    string cin;     ///< National identity card number (unique identifier)
    string nom;     ///< Last name
    string prenom;  ///< First name

public:
    /**
     * @brief Constructs a personne with the given identity fields.
     * @param c  CIN (carte d'identité nationale)
     * @param n  Last name
     * @param p  First name
     */
    personne(string c, string n, string p);

    /** @brief Returns the CIN. */
    string getCIN() const;

    /** @brief Returns the last name. */
    string getNom() const;

    /** @brief Returns the first name. */
    string getPrenom() const;

    /** @brief Updates the last name. */
    void setNom(string n);

    /** @brief Updates the first name. */
    void setPrenom(string p);
};

#endif
