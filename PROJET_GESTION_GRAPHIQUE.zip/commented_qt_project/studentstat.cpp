/**
 * @file studentstat.cpp
 * @brief Implementation of the studentstat read-only statistics dialog.
 */

#include "studentstat.h"
#include "ui_studentstat.h"
#include <QString>
#include <QTableWidgetItem>

/** Sets up the UI, connects the close button, and immediately loads stats. */
studentstat::studentstat(etudiant* e, QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::studentstat)
    , etudiantCourant(e)
{
    ui->setupUi(this);
    connect(ui->pushButton, &QPushButton::clicked, this, &QDialog::close);
    chargerStats();
}

studentstat::~studentstat() { delete ui; }

/**
 * Fills the dialog with the student's statistics:
 *  - Top labels: name, general average, decision, best/weakest module.
 *  - Table rows: one per module → title, current average, EXAM grade needed.
 *
 * "Note nécessaire" display logic:
 *   < 0  → "N/A"           (no EXAM component or module not found)
 *   = 0  → "Deja valide"   (already passing without the exam)
 *   > 20 → "Impossible"    (cannot reach 10 even with 20/20 on exam)
 *   else → formatted float (exact grade needed)
 */
void studentstat::chargerStats()
{
    if (!etudiantCourant) return;

    // Populate the summary labels
    ui->name->setText(QString::fromStdString(
        etudiantCourant->getNom() + " " + etudiantCourant->getPrenom()));

    ui->moygen->setText(QString::number(etudiantCourant->calculMoyenneGenerale(), 'f', 2) + " / 20");
    ui->statut->setText(QString::fromStdString(etudiantCourant->decisionAcademique()));
    ui->meilleumatiere->setText(QString::fromStdString(etudiantCourant->meilleurModule()));
    ui->matiereplusfaible->setText(QString::fromStdString(etudiantCourant->moduleFaible()));

    // Populate the per-module table
    ui->tableWidget->setRowCount((int)etudiantCourant->modules.size());
    for (int i = 0; i < (int)etudiantCourant->modules.size(); i++) {
        module* m = etudiantCourant->modules[i];
        float mMoy = m->moyenneModule();
        float noteNeeded = etudiantCourant->noteNecessaire(m->code);

        // Format the "note nécessaire" cell based on the returned value
        QString noteStr;
        if (noteNeeded < 0)       noteStr = "N/A";
        else if (noteNeeded == 0) noteStr = "Deja valide";
        else if (noteNeeded > 20) noteStr = "Impossible";
        else                      noteStr = QString::number(noteNeeded, 'f', 2);

        ui->tableWidget->setItem(i, 0, new QTableWidgetItem(QString::fromStdString(m->intitule)));
        ui->tableWidget->setItem(i, 1, new QTableWidgetItem(QString::number(mMoy, 'f', 2)));
        ui->tableWidget->setItem(i, 2, new QTableWidgetItem(noteStr));
    }
    ui->tableWidget->resizeColumnsToContents();
}
