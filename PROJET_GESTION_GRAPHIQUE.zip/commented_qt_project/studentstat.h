/**
 * @file studentstat.h
 * @brief Read-only student statistics dialog.
 *
 * Displays the logged-in student's:
 *   - Full name
 *   - General average and academic decision (Admis / Ajourné)
 *   - Best and weakest modules
 *   - Per-module table: module name, current average, EXAM grade needed to pass
 */

#ifndef STUDENTSTAT_H
#define STUDENTSTAT_H

#include <QDialog>
#include "etudiant.h"

namespace Ui { class studentstat; }

/**
 * @class studentstat
 * @brief Student statistics view (read-only).
 *
 * Receives a non-owning pointer to the student and populates the UI
 * immediately in the constructor via chargerStats().
 */
class studentstat : public QDialog
{
    Q_OBJECT

public:
    /**
     * @brief Constructs the stats dialog and loads data immediately.
     * @param e       Non-owning pointer to the logged-in student.
     * @param parent  Parent widget.
     */
    explicit studentstat(etudiant* e, QWidget *parent = nullptr);
    ~studentstat();

private:
    Ui::studentstat *ui;
    etudiant* etudiantCourant;  ///< Non-owning pointer to the currently viewed student

    /** @brief Populates all labels and the table widget with the student's data. */
    void chargerStats();
};

#endif // STUDENTSTAT_H
