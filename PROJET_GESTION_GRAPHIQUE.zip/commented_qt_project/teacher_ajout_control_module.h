/**
 * @file teacher_ajout_control_module.h
 * @brief Teacher dialog — add an assessment to a module.
 *
 * Input: CNE, module code, type (TP/CC/EXAM), grade (0-20).
 * Assigns the standard weight automatically: TP=20%, CC=30%, EXAM=50%.
 */

#ifndef TEACHER_AJOUT_CONTROL_MODULE_H
#define TEACHER_AJOUT_CONTROL_MODULE_H

#include <QDialog>
#include <vector>
#include "etudiant.h"

namespace Ui { class teacher_ajout_control_module; }

class teacher_ajout_control_module : public QDialog
{
    Q_OBJECT
public:
    explicit teacher_ajout_control_module(vector<etudiant*>* etudiants, QWidget *parent = nullptr);
    ~teacher_ajout_control_module();
private slots:
    void on_sauvegarder();
private:
    Ui::teacher_ajout_control_module *ui;
    vector<etudiant*>* etudiants;
};

#endif
