/**
 * @file main.cpp
 * @brief Application entry point.
 *
 * Creates the QApplication, attempts a database connection,
 * shows the main window, and disconnects from the DB on exit.
 */

#include <QApplication>
#include "mainwindow.h"
#include "database.h"

int main(int argc, char *argv[])
{
    QApplication app(argc, argv);

    // Connect to database at startup
    if (!db_connect()) {
        // App can still run, but SQL features won't work
        qDebug() << "Warning: running without database connection";
    }

    MainWindow w;
    w.show();

    int result = app.exec();

    db_disconnect();
    return result;
}
