/**
 * @file teacher_affich_tout_etud.cpp
 * @brief Implementation of the "show all students" teacher dialog.
 *
 * Fills a QTableWidget with one row per student on construction.
 */

#include "teacher_affich_tout_etud.h"
#include "ui_teacher_affich_tout_etud.h"
#include <QTableWidgetItem>

teacher_affich_tout_etud::teacher_affich_tout_etud(vector<etudiant*>* etudiants, QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::teacher_affich_tout_etud)
    , etudiants(etudiants)
{
    ui->setupUi(this);

    ui->tableWidget->setRowCount((int)etudiants->size());
    for (int i = 0; i < (int)etudiants->size(); i++) {
        etudiant* e = (*etudiants)[i];
        ui->tableWidget->setItem(i, 0, new QTableWidgetItem(QString::fromStdString(e->getCNE())));
        ui->tableWidget->setItem(i, 1, new QTableWidgetItem(QString::fromStdString(e->getCIN())));
        ui->tableWidget->setItem(i, 2, new QTableWidgetItem(QString::fromStdString(e->getNom())));
        ui->tableWidget->setItem(i, 3, new QTableWidgetItem(QString::fromStdString(e->getPrenom())));
    }
    ui->tableWidget->resizeColumnsToContents();

    connect(ui->pushButton, &QPushButton::clicked, this, &QDialog::close);
}

teacher_affich_tout_etud::~teacher_affich_tout_etud()
{
    delete ui;
}
