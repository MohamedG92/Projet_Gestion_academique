/**
 * @file teacher_ajouter_etu.h
 * @brief Teacher dialog — add a new student.
 *
 * Input fields: CIN, Nom, Prénom, CNE.
 * Validates that CIN and CNE are unique before inserting.
 */

#ifndef TEACHER_AJOUTER_ETU_H
#define TEACHER_AJOUTER_ETU_H

#include <QDialog>
#include <vector>
#include "etudiant.h"

namespace Ui { class teacher_ajouter_etu; }

/**
 * @class teacher_ajouter_etu
 * @brief Form dialog for adding a new student to the system.
 */
class teacher_ajouter_etu : public QDialog
{
    Q_OBJECT
public:
    explicit teacher_ajouter_etu(vector<etudiant*>* etudiants, QWidget *parent = nullptr);
    ~teacher_ajouter_etu();
private slots:
    void on_sauvegarder();  ///< Validates inputs, creates an etudiant, and saves to DB
private:
    Ui::teacher_ajouter_etu *ui;
    vector<etudiant*>* etudiants;  ///< Non-owning pointer to the master student list
};

#endif
