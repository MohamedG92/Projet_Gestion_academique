cmake_minimum_required(VERSION 3.16)
project(gestion_scolaire VERSION 0.1 LANGUAGES CXX)

set(CMAKE_AUTOUIC ON)
set(CMAKE_AUTOMOC ON)
set(CMAKE_AUTORCC ON)
set(CMAKE_CXX_STANDARD 17)
set(CMAKE_CXX_STANDARD_REQUIRED ON)

find_package(QT NAMES Qt6 Qt5 REQUIRED COMPONENTS Widgets Sql)
find_package(Qt${QT_VERSION_MAJOR} REQUIRED COMPONENTS Widgets Sql)

set(PROJECT_SOURCES
    main.cpp

    # Data model classes (from project 1)
    personne.h personne.cpp
    etudiant.h etudiant.cpp
    enseignant.h enseignant.cpp
    module.h module.cpp
    controle.h controle.cpp
    note.h note.cpp

    # Database layer (Qt SQL version)
    database.h database.cpp

    # Qt UI windows (from project 2)
    mainwindow.h mainwindow.cpp mainwindow.ui
    loginstudent.h loginstudent.cpp loginstudent.ui
    dialog.h dialog.cpp dialog.ui

    teacher_ajouter_etu.h teacher_ajouter_etu.cpp teacher_ajouter_etu.ui
    teacher_suppr_module.h teacher_suppr_module.cpp teacher_suppr_module.ui
    teacher_mod_etud.h teacher_mod_etud.cpp teacher_mod_etud.ui
    teacher_recher_etud.h teacher_recher_etud.cpp teacher_recher_etud.ui
    teacher_ajout_control_module.h teacher_ajout_control_module.cpp teacher_ajout_control_module.ui
    teacher_modi_note.h teacher_modi_note.cpp teacher_modi_note.ui
    teacher_affich_tout_etud.h teacher_affich_tout_etud.cpp teacher_affich_tout_etud.ui
    teacher_stat.h teacher_stat.cpp teacher_stat.ui

    studentstat.h studentstat.cpp studentstat.ui
)

qt_add_executable(gestion_scolaire
    MANUAL_FINALIZATION
    ${PROJECT_SOURCES}
)

target_link_libraries(gestion_scolaire PRIVATE
    Qt${QT_VERSION_MAJOR}::Widgets
    Qt${QT_VERSION_MAJOR}::Sql
)

set_target_properties(gestion_scolaire PROPERTIES
    MACOSX_BUNDLE TRUE
    WIN32_EXECUTABLE TRUE
)

if(QT_VERSION_MAJOR EQUAL 6)
    qt_finalize_executable(gestion_scolaire)
endif()
