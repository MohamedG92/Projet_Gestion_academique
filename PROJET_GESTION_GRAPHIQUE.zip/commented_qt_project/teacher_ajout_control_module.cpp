/**
 * @file teacher_ajout_control_module.cpp
 * @brief Implementation of the "add assessment" teacher dialog.
 */

#include "teacher_ajout_control_module.h"
#include "ui_teacher_ajout_control_module.h"
#include "database.h"
#include <QMessageBox>

teacher_ajout_control_module::teacher_ajout_control_module(vector<etudiant*>* etudiants, QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::teacher_ajout_control_module)
    , etudiants(etudiants)
{
    ui->setupUi(this);
    connect(ui->pushButton,   &QPushButton::clicked, this, &teacher_ajout_control_module::on_sauvegarder);
    connect(ui->pushButton_2, &QPushButton::clicked, this, &QDialog::close);
}

teacher_ajout_control_module::~teacher_ajout_control_module() { delete ui; }

void teacher_ajout_control_module::on_sauvegarder()
{
    // lineEdit=CNE, lineEdit_2=code module, lineEdit_3=type(TP/CC/EXAM), lineEdit_4=note
    QString cne      = ui->lineEdit->text().trimmed();
    QString codeMod  = ui->lineEdit_2->text().trimmed();
    QString type     = ui->lineEdit_3->text().trimmed().toUpper();
    QString noteStr  = ui->lineEdit_4->text().trimmed();

    if (cne.isEmpty() || codeMod.isEmpty() || type.isEmpty() || noteStr.isEmpty()) {
        QMessageBox::warning(this, "Erreur", "Veuillez remplir tous les champs."); return;
    }
    if (type != "TP" && type != "CC" && type != "EXAM") {
        QMessageBox::warning(this, "Erreur", "Type doit etre TP, CC ou EXAM."); return;
    }
    bool ok; float note = noteStr.toFloat(&ok);
    if (!ok || note < 0 || note > 20) { QMessageBox::warning(this, "Erreur", "Note invalide (0-20)."); return; }

    etudiant* cible = nullptr;
    for (int i = 0; i < (int)etudiants->size(); i++)
        if ((*etudiants)[i]->getCNE() == cne.toStdString()) { cible = (*etudiants)[i]; break; }
    if (!cible) { QMessageBox::warning(this, "Erreur", "Etudiant introuvable."); return; }

    bool found = false;
    for (int i = 0; i < (int)cible->modules.size(); i++)
        if (cible->modules[i]->code == codeMod.toStdString()) { found = true; break; }
    if (!found) { QMessageBox::warning(this, "Erreur", "Module introuvable."); return; }

    float pct = (type == "TP") ? 20.0f : (type == "CC") ? 30.0f : 50.0f;
    controle* c = new controle(type.toStdString(), pct, note);
    cible->ajouterControle(codeMod.toStdString(), c);
    db_save_etudiant(cible);
    QMessageBox::information(this, "Succes", "Controle ajoute !");
    ui->lineEdit->clear(); ui->lineEdit_2->clear();
    ui->lineEdit_3->clear(); ui->lineEdit_4->clear();
}
