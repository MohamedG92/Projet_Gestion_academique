/**
 * @file teacher_modi_note.cpp
 * @brief Implementation of the "modify grade" teacher dialog.
 */

#include "teacher_modi_note.h"
#include "ui_teacher_modi_note.h"
#include "database.h"
#include <QMessageBox>

teacher_modi_note::teacher_modi_note(vector<etudiant*>* etudiants, QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::teacher_modi_note)
    , etudiants(etudiants)
{
    ui->setupUi(this);
    connect(ui->pushButton_2, &QPushButton::clicked, this, &teacher_modi_note::on_sauvegarder);
    connect(ui->pushButton,   &QPushButton::clicked, this, &QDialog::close);
}

teacher_modi_note::~teacher_modi_note() { delete ui; }

void teacher_modi_note::on_sauvegarder()
{
    // lineEdit=CNE, lineEdit_2=code module, lineEdit_3=type, lineEdit_4=nouvelle note
    QString cne     = ui->lineEdit->text().trimmed();
    QString codeMod = ui->lineEdit_2->text().trimmed();
    QString type    = ui->lineEdit_3->text().trimmed().toUpper();
    QString noteStr = ui->lineEdit_4->text().trimmed();

    if (cne.isEmpty() || codeMod.isEmpty() || type.isEmpty() || noteStr.isEmpty()) {
        QMessageBox::warning(this, "Erreur", "Veuillez remplir tous les champs."); return;
    }
    bool ok; float note = noteStr.toFloat(&ok);
    if (!ok || note < 0 || note > 20) { QMessageBox::warning(this, "Erreur", "Note invalide (0-20)."); return; }

    etudiant* cible = nullptr;
    for (int i = 0; i < (int)etudiants->size(); i++)
        if ((*etudiants)[i]->getCNE() == cne.toStdString()) { cible = (*etudiants)[i]; break; }
    if (!cible) { QMessageBox::warning(this, "Erreur", "Etudiant introuvable."); return; }

    if (!cible->modifierNote(codeMod.toStdString(), type.toStdString(), note)) {
        QMessageBox::warning(this, "Erreur", "Module ou type introuvable."); return;
    }
    db_save_etudiant(cible);
    QMessageBox::information(this, "Succes", "Note modifiee !");
    ui->lineEdit->clear(); ui->lineEdit_2->clear();
    ui->lineEdit_3->clear(); ui->lineEdit_4->clear();
}
