/**
 * @file mainwindow.h
 * @brief Main window — the application's landing screen.
 *
 * Displays two login buttons:
 *   - "Professeur" → opens the teacher login dialog (Dialog)
 *   - "Étudiant"   → opens the student login dialog (loginstudent)
 *
 * The two shared data vectors (etudiants, enseignants) live here and are
 * passed by pointer to every child dialog so all windows share the same data.
 * Data is loaded at startup and saved back to the DB on close.
 */

#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <vector>
#include "etudiant.h"
#include "enseignant.h"

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

/**
 * @class MainWindow
 * @brief Application root window.
 *
 * Owns the master copies of the etudiants and enseignants lists.
 * Destructor saves all students back to the DB and frees all memory.
 */
class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void on_pushButton_clicked();    ///< Teacher login button → opens Dialog
    void on_pushButton_2_clicked();  ///< Student login button → opens loginstudent

private:
    Ui::MainWindow *ui;

    // Shared data loaded from DB at startup
    vector<etudiant*>   etudiants;    ///< All students (shared with child dialogs)
    vector<enseignant*> enseignants;  ///< All teachers (shared with child dialogs)
};

#endif // MAINWINDOW_H
