/**
 * @file teacher_suppr_module.h
 * @brief Teacher dialog — remove a module from a student's record.
 *
 * Input fields: CNE (identifies the student), module code.
 * Deletes the module from both the DB and the in-memory list.
 */

#ifndef TEACHER_SUPPR_MODULE_H
#define TEACHER_SUPPR_MODULE_H

#include <QDialog>
#include <vector>
#include "etudiant.h"

namespace Ui { class teacher_suppr_module; }

class teacher_suppr_module : public QDialog
{
    Q_OBJECT
public:
    explicit teacher_suppr_module(vector<etudiant*>* etudiants, QWidget *parent = nullptr);
    ~teacher_suppr_module();
private slots:
    void on_sauvegarder();
private:
    Ui::teacher_suppr_module *ui;
    vector<etudiant*>* etudiants;
};

#endif
