/**
 * @file loginstudent.cpp
 * @brief Implementation of the student login dialog.
 */

#include "loginstudent.h"
#include "ui_loginstudent.h"
#include "studentstat.h"
#include <QMessageBox>

loginstudent::loginstudent(vector<etudiant*>* etudiants, QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::loginstudent)
    , etudiants(etudiants)
    , etudiantConnecte(nullptr)  // No student logged in yet
{
    ui->setupUi(this);
}

loginstudent::~loginstudent()
{
    delete ui;
}

/**
 * Searches the student list for a matching CNE.
 * If found, opens the studentstat dialog with the located student.
 * If not found, shows an error and stays on the login screen.
 */
void loginstudent::on_pushButton_clicked()
{
    // Login: find student by CNE
    QString cne = ui->lineEdit->text().trimmed();
    if (cne.isEmpty()) {
        QMessageBox::warning(this, "Erreur", "Veuillez entrer votre CNE.");
        return;
    }

    etudiantConnecte = nullptr;
    for (int i = 0; i < (int)etudiants->size(); i++) {
        if ((*etudiants)[i]->getCNE() == cne.toStdString()) {
            etudiantConnecte = (*etudiants)[i];
            break;
        }
    }

    if (etudiantConnecte == nullptr) {
        QMessageBox::warning(this, "Erreur", "CNE introuvable.");
        return;
    }

    // Open student stats page (read-only view)
    studentstat statsPage(etudiantConnecte, this);
    statsPage.setModal(true);
    statsPage.exec();
}

void loginstudent::on_pushButton_2_clicked()
{
    this->close();
}
