// ============================================================
// note.h
// Represents a numeric grade (note) on a 0–20 scale.
// Used internally by the `controle` class to store a grade.
// ============================================================

#ifndef NOTE_H
#define NOTE_H

#include <iostream>
using namespace std;

class note {
private:
    float n;  // The grade value, must stay between 0 and 20

public:
    // Constructor: initializes the grade (defaults to 0 if not specified)
    note(float val = 0);

    // Prompts the user to input a grade from the console (validates 0–20)
    void saisir();

    // Prints the grade value to the console
    void afficher() const;

    // Returns the current grade value
    float getNote() const;

    // Sets a new grade value; clamps it to [0, 20]
    void setNote(float val);
};

#endif
