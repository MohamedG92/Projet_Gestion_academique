// ============================================================
// module.cpp
// Implementation of the module class.
// Handles assessment management and grade calculation
// for a single academic module (course).
// ============================================================

#include "module.h"

// Constructor: initializes all module fields with given values
module::module(string c, string i, int coef, string ens, int sem)
    : code(c), intitule(i), coefficient(coef), codeEnseignant(ens), semestre(sem) {}

// Destructor: deletes all heap-allocated controle objects in the list
module::~module() {
    for (size_t i = 0; i < controles.size(); i++) {
        delete controles[i];
    }
}

// Appends a new controle (assessment) to this module's list
void module::ajouterControle(controle* c) {
    controles.push_back(c);
}

// Searches for a controle matching the given type and updates its grade.
// Returns true if found and updated, false if no matching type was found.
bool module::modifierNote(const string& type, float nouvelleNote) {
    for (size_t i = 0; i < controles.size(); i++) {
        if (controles[i]->getType() == type) {
            controles[i]->setNote(nouvelleNote);
            return true;
        }
    }
    return false;
}

// Calculates the weighted average of the module.
// Each controle contributes: grade * (percentage / 100).
// Example with TP=14 (20%), CC=12 (30%), EXAM=16 (50%):
//   average = 14*0.2 + 12*0.3 + 16*0.5 = 14.4
float module::moyenneModule() const {
    float somme = 0;
    for (size_t i = 0; i < controles.size(); i++) {
        somme += controles[i]->getNote() * controles[i]->getPourcentage() / 100.0;
    }
    return somme;
}
