# Academic Management System — C++ with MariaDB (XAMPP)

A console-based C++ application for managing students, teachers, modules, and grades. All data is stored in a local MariaDB database running through XAMPP.

---

## What This Project Does

- Teachers can log in and manage students: add, edit, delete, and search
- Teachers can assign modules (courses) and enter grades (TP, CC, EXAM)
- Students can log in with their CNE to view their grades, average, and academic status
- All data is saved to a local MariaDB database automatically

---

## Requirements

- Windows PC
- XAMPP (includes Apache + MariaDB)
- Dev-C++ or any C++ IDE that supports MinGW
- The `libmariadb.dll` file (already included in the project folder)

---

## Step 1 — Download and Install XAMPP

1. Go to: https://www.apachefriends.org/download.html
2. Download the **Windows** version of XAMPP
3. Run the installer and follow the steps (default options are fine)
4. Once installed, open the **XAMPP Control Panel** from your Start menu
5. Click **Start** next to **MySQL** (this starts the MariaDB database server)
6. The MySQL status light should turn green — this means the database is running

> XAMPP must be running with MySQL started every time you use this program.

---

## Step 2 — Set Up the Database

1. With XAMPP running, open your browser and go to: http://localhost/phpmyadmin
2. Click **New** on the left sidebar to create a new database
3. Name it exactly: `khdaminshalah` and click **Create**
4. Select the `khdaminshalah` database, then click the **SQL** tab at the top
5. Paste and run the following SQL to create the required tables:

```sql
CREATE TABLE etudiants (
    cin     VARCHAR(20) PRIMARY KEY,
    nom     VARCHAR(100),
    prenom  VARCHAR(100),
    cne     VARCHAR(20) UNIQUE
);

CREATE TABLE enseignants (
    cin     VARCHAR(20) PRIMARY KEY,
    nom     VARCHAR(100),
    prenom  VARCHAR(100),
    code    VARCHAR(50) UNIQUE
);

CREATE TABLE modules (
    id              INT AUTO_INCREMENT PRIMARY KEY,
    code            VARCHAR(50),
    intitule        VARCHAR(200),
    coefficient     INT,
    codeEnseignant  VARCHAR(50),
    semestre        INT,
    etudiant_cin    VARCHAR(20),
    FOREIGN KEY (etudiant_cin) REFERENCES etudiants(cin) ON DELETE CASCADE
);

CREATE TABLE controles (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    type        VARCHAR(20),
    pourcentage FLOAT,
    note        FLOAT,
    module_id   INT,
    FOREIGN KEY (module_id) REFERENCES modules(id) ON DELETE CASCADE
);
```

6. Click **Go** to execute — you should see a success message

---

## Step 3 — Open the Project in Dev-C++

1. Download and install Dev-C++: https://www.bloodshed.net or https://github.com/Embarcadero/Dev-Cpp/releases
2. Open Dev-C++ and go to **File → Open Project**
3. Navigate to the project folder and open `khdaminchalah.dev`
4. Make sure the file `libmariadb.dll` is in the **same folder** as the `.exe` — it is already included

---

## Step 4 — Configure the MariaDB Library in Dev-C++

If the project does not compile, you may need to link the MariaDB library manually:

1. In Dev-C++, go to **Project → Project Options → Parameters**
2. In the **Linker** field, add: `-lmariadb`
3. Go to **Project → Project Options → Directories → Library Directories**
4. Add the path to your MariaDB lib folder, for example:  
   `C:\xampp\mysql\lib`
5. Go to **Include Directories** and add:  
   `C:\xampp\mysql\include`
6. Click OK and try building again

---

## Step 5 — Run the Program

1. Make sure XAMPP is running and MySQL is started
2. Press **F9** in Dev-C++ to compile and run, or double-click the `.exe` in the project folder
3. The program will connect to the database automatically and load existing data
4. If it says `Base de donnees connectee.` — you are good to go!

---

## How to Use

### Login Screen
- **Option 1** — Log in as a teacher (requires teacher code + password `Admin`)
- **Option 2** — Register as a new teacher
- **Option 3** — Log in as a student (requires CNE only)
- **Option 4** — Exit the program

### Teacher Menu
Once logged in as a teacher you can:
- Add / edit / delete students
- Add modules (courses) to students — automatically linked to your teacher code
- Enter grades for TP (20%), CC (30%), and EXAM (50%)
- Modify existing grades
- Search for students by name or CNE
- View statistics: pass rate, top student, students at risk

### Student Menu
Once logged in with your CNE you can:
- View all your modules and grades
- See your overall weighted average
- Check if you are admitted (Admis) or deferred (Ajourne)
- See your best and weakest modules
- Calculate the minimum exam score needed to pass a specific module

---

## Default Password

All teacher accounts share the same password: **`Admin`**

---

## Database Connection Details (hard-coded in `Database.cpp`)

| Setting  | Value           |
|----------|-----------------|
| Host     | 127.0.0.1       |
| Port     | 3306            |
| User     | root            |
| Password | *(empty)*       |
| Database | khdaminshalah   |

If your XAMPP MySQL root user has a password set, update the `db_connect()` function in `Database.cpp` accordingly.

---

## Troubleshooting

**"Erreur connexion DB"** — XAMPP MySQL is not running. Open XAMPP Control Panel and click Start next to MySQL.

**"mysql_init failed"** — The `libmariadb.dll` file is missing from the folder. Make sure it is in the same directory as the `.exe`.

**Program compiles but crashes immediately** — Check that the database name is exactly `khdaminshalah` (no capital letters, no spaces).

**French characters display incorrectly** — Make sure your console is set to UTF-8. You can run `chcp 65001` in your terminal before launching the program.
