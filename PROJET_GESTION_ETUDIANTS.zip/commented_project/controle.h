// ============================================================
// controle.h
// Represents an assessment (controle) for a module.
// Each controle has a type (e.g., "TP", "CC", "EXAM"),
// a percentage weight in the final grade, and a note object.
//
// Typical weighting in this system:
//   TP   = 20%
//   CC   = 30%
//   EXAM = 50%
// ============================================================

#ifndef CONTROLE_H
#define CONTROLE_H

#include "note.h"
#include <string>
using namespace std;

class controle {
    string type;       // Type of assessment: "TP", "CC", or "EXAM"
    float pourcentage; // Weight of this assessment in the module average (e.g., 20.0 for 20%)
    note* n;           // Pointer to the grade object for this assessment

public:
    // Constructor: creates a controle with a given type, percentage weight, and initial grade
    controle(string t, float p, float val);

    // Destructor: frees the dynamically allocated note object
    ~controle();

    // Returns the numeric grade for this assessment
    float getNote() const;

    // Returns the percentage weight of this assessment
    float getPourcentage() const;

    // Returns the type of this assessment ("TP", "CC", or "EXAM")
    string getType() const;

    // Updates the grade for this assessment
    void setNote(float val);
};

#endif
