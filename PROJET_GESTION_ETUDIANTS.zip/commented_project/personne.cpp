// ============================================================
// personne.cpp
// Implementation of the personne base class.
// Provides constructor and getter/setter methods shared
// by both etudiant and enseignant.
// ============================================================

#include "personne.h"

// Constructor: sets CIN, nom, and prenom from the given parameters
personne::personne(string c, string n, string p): cin(c), nom(n), prenom(p) {}

// Returns the person's national ID (CIN)
string personne::getCIN() const { return cin; }

// Returns the person's last name
string personne::getNom() const { return nom; }

// Returns the person's first name
string personne::getPrenom() const { return prenom; }

// Updates the person's last name
void personne::setNom(string n) { nom = n; }

// Updates the person's first name
void personne::setPrenom(string p) { prenom = p; }
