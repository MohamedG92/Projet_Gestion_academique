// ============================================================
// personne.h
// Base class representing a person (student or teacher).
// Contains common identity fields: CIN, nom (last name),
// and prenom (first name).
// Both `etudiant` and `enseignant` inherit from this class.
// ============================================================

#ifndef PERSONNE_H
#define PERSONNE_H

#include <string>
using namespace std;

// Base class for any person in the academic system
class personne {
protected:
    string cin;     // National ID card number (Carte d'Identite Nationale)
    string nom;     // Last name
    string prenom;  // First name

public:
    // Constructor: initializes CIN, nom, and prenom
    personne(string c, string n, string p);

    // Getters
    string getCIN() const;    // Returns the CIN
    string getNom() const;    // Returns the last name
    string getPrenom() const; // Returns the first name

    // Setters
    void setNom(string n);    // Updates the last name
    void setPrenom(string p); // Updates the first name
};

#endif
