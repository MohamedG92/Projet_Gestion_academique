// ============================================================
// main.cpp
// Entry point and interactive console menu for the Academic
// Management System.
//
// This program manages students (etudiants) and teachers
// (enseignants) with full CRUD operations, grade management,
// and academic statistics. All data is persisted to a local
// MariaDB/MySQL database via XAMPP.
//
// Two user roles are supported:
//   - Enseignant (Teacher): full admin access
//   - Etudiant  (Student): read-only view of own data
//
// Default password for all teachers: "Admin"
// ============================================================

#include <iostream>
#include <vector>
#include <string>
#include <conio.h>   // For getch() — masked password input (Windows only)
#include <mysql.h>
#include "etudiant.h"
#include "module.h"
#include "controle.h"
#include "enseignant.h"
#include "personne.h"
#include "Database.h"
using namespace std;

// Global MySQL connection handle — shared across all DB functions
MYSQL* conn = NULL;

// ---------------------------------------------------------------
// lireChoix()
// Reads a menu choice from stdin as a string and converts it
// to an integer manually (avoids issues with cin >> int on
// invalid input causing stream failures).
// ---------------------------------------------------------------
int lireChoix() {
    string s;
    cin >> s;
    int n = 0;
    for (int i = 0; i < (int)s.size(); i++)
        n = n * 10 + (s[i] - '0');
    return n;
}

// ---------------------------------------------------------------
// lireMotDePasse()
// Reads a password from the console character by character,
// displaying '*' instead of the actual character.
// Supports backspace to delete the last character.
// Uses getch() — Windows-specific (conio.h).
// ---------------------------------------------------------------
string lireMotDePasse() {
    string mdp = "";
    char c;
    while ((c = getch()) != '\r') { // '\r' = Enter key
        if (c == '\b') // Backspace check
        {
            if (!mdp.empty()) {
                mdp.erase(mdp.size() - 1);  // Remove last character
                cout << "\b \b";             // Erase the '*' on screen
            }
        } else {
            mdp += c;       // Append the typed character to password
            cout << '*';    // Show '*' instead of actual character
        }
    }
    cout << endl;
    return mdp;
}

// ---------------------------------------------------------------
// gererMenuEnseignant()
// Displays the teacher (enseignant) menu and handles all
// teacher actions including:
//   1. Add student          6. Remove module
//   2. Remove student       7. Add assessments to module
//   3. Edit student         8. Modify a grade
//   4. Search student       9. Display all students
//   5. Add module          10. Statistics
//                          11. Logout
// All changes are immediately persisted to the database.
// ---------------------------------------------------------------
void gererMenuEnseignant(vector<etudiant*>& etudiants, enseignant* ens, int& choix) {
    system("pause");
    system("cls"); // Clear the console screen
    cout << "\n--- Menu Enseignant : " << ens->getNom() << " " << ens->getPrenom() << " ---\n";
    cout << " 1. Ajouter un etudiant\n";
    cout << " 2. Supprimer un etudiant\n";
    cout << " 3. Modifier un etudiant\n";
    cout << " 4. Rechercher un etudiant\n";
    cout << " 5. Ajouter un module a un etudiant\n";
    cout << " 6. Supprimer un module\n";
    cout << " 7. Ajouter des controles a un module\n";
    cout << " 8. Modifier une note\n";
    cout << " 9. Afficher tous les etudiants\n";
    cout << "10. Statistiques\n";
    cout << "11. Se deconnecter\n";
    cout << "Choix: ";
    choix = lireChoix();

    switch (choix) {
        case 1: {
            // --- Add a new student ---
            string cin_, nom, prenom, cne;
            cout << "CIN: ";    cin >> cin_;
            cout << "Nom: ";    cin >> nom;
            cout << "Prenom: "; cin >> prenom;
            cout << "CNE: ";    cin >> cne;

            // Check for duplicate CIN or CNE before adding
            bool cinExiste = false, cneExiste = false;
            for (size_t i = 0; i < etudiants.size(); i++) {
                if (etudiants[i]->personne::getCIN() == cin_) cinExiste = true;
                if (etudiants[i]->getCNE() == cne) cneExiste = true;
            }
            if (cinExiste) { cout << "Erreur : CIN deja utilise !\n"; break; }
            if (cneExiste) { cout << "Erreur : CNE deja utilise !\n"; break; }

            etudiant* nouveau = new etudiant(cin_, nom, prenom, cne);
            etudiants.push_back(nouveau);
            db_save_etudiant(conn, nouveau); // Persist to database immediately
            cout << "Etudiant ajoute et sauvegarde.\n";
            break;
        }
        case 2: {
            // --- Delete a student by CNE ---
            string cne;
            cout << "CNE de l'etudiant a supprimer: "; cin >> cne;
            bool trouve = false;
            for (size_t i = 0; i < etudiants.size(); i++) {
                if (etudiants[i]->getCNE() == cne) {
                    db_delete_etudiant(conn, cne); // Remove from database first
                    delete etudiants[i];           // Free memory
                    etudiants.erase(etudiants.begin() + i); // Remove from vector
                    cout << "Etudiant supprime avec succes.\n";
                    trouve = true;
                    break;
                }
            }
            if (!trouve) cout << "Etudiant non trouve.\n";
            break;
        }
        case 3: {
            // --- Edit an existing student's name and CNE ---
            string cne;
            cout << "CNE de l'etudiant a modifier: "; cin >> cne;
            etudiant* etu = NULL;
            for (size_t i = 0; i < etudiants.size(); i++) {
                if (etudiants[i]->getCNE() == cne) { etu = etudiants[i]; break; }
            }
            if (!etu) { cout << "Etudiant non trouve.\n"; break; }
            string nom, prenom, nouveauCne;
            cout << "Nouveau nom: ";    cin >> nom;
            cout << "Nouveau prenom: "; cin >> prenom;
            cout << "Nouveau CNE: ";    cin >> nouveauCne;
            etu->setNom(nom);
            etu->setPrenom(prenom);
            etu->setCNE(nouveauCne);
            db_save_etudiant(conn, etu); // Save changes to database
            cout << "Etudiant modifie et sauvegarde.\n";
            break;
        }
        case 4: {
            // --- Search for a student by CNE or last name ---
            string recherche;
            cout << "Entrez CNE ou nom: "; cin >> recherche;
            bool trouve = false;
            for (size_t i = 0; i < etudiants.size(); i++) {
                if (etudiants[i]->getCNE() == recherche || etudiants[i]->getNom() == recherche) {
                    cout << "\nEtudiant trouve:\n";
                    cout << "  CIN: "    << etudiants[i]->personne::getCIN() << endl;
                    cout << "  Nom: "    << etudiants[i]->getNom() << endl;
                    cout << "  Prenom: " << etudiants[i]->getPrenom() << endl;
                    cout << "  CNE: "    << etudiants[i]->getCNE() << endl;
                    etudiants[i]->afficherModules(); // Also print all modules/grades
                    trouve = true;
                }
            }
            if (!trouve) cout << "Aucun etudiant trouve.\n";
            break;
        }
        case 5: {
            // --- Add a module to a specific student ---
            // The module is automatically attributed to the currently logged-in teacher
            string cne;
            cout << "CNE etudiant: "; cin >> cne;
            etudiant* etu = NULL;
            for (size_t i = 0; i < etudiants.size(); i++) {
                if (etudiants[i]->getCNE() == cne) { etu = etudiants[i]; break; }
            }
            if (!etu) { cout << "Etudiant non trouve.\n"; break; }
            string code, intit;
            int coef, sem;
            cout << "Code module: "; cin >> code;
            cout << "Intitule: ";    cin >> intit;
            cout << "Coefficient: "; cin >> coef;
            cout << "Semestre: ";    cin >> sem;
            // Automatically assign the current teacher's code to the new module
            etu->ajouterModule(new module(code, intit, coef, ens->getCode(), sem));
            db_save_etudiant(conn, etu); // Save to database
            cout << "Module ajoute (Enseignant: " << ens->getNom() << " - " << ens->getCode() << ").\n";
            break;
        }
        case 6: {
            // --- Remove a specific module from a student ---
            string cne, codeModule;
            cout << "CNE etudiant: ";           cin >> cne;
            etudiant* etu = NULL;
            for (size_t i = 0; i < etudiants.size(); i++) {
                if (etudiants[i]->getCNE() == cne) { etu = etudiants[i]; break; }
            }
            if (!etu) { cout << "Etudiant non trouve.\n"; break; }
            cout << "Code module a supprimer: "; cin >> codeModule;
            etu->supprimerModule(codeModule); // Handles removal from memory
            db_save_etudiant(conn, etu);      // Re-sync with database
            break;
        }
        case 7: {
            // --- Add TP, CC, and EXAM assessments to a module ---
            // Fixed weighting: TP=20%, CC=30%, EXAM=50%
            string cne, codeModule;
            cout << "CNE etudiant: "; cin >> cne;
            etudiant* etu = NULL;
            for (size_t i = 0; i < etudiants.size(); i++) {
                if (etudiants[i]->getCNE() == cne) { etu = etudiants[i]; break; }
            }
            if (!etu) { cout << "Etudiant non trouve.\n"; break; }
            cout << "Code module: "; cin >> codeModule;
            float noteTP, noteCC, noteEXAM;

            // Input validation loops: force user to enter a valid grade [0–20]
            cout << "Note TP (0-20): ";
            do { cin >> noteTP;   if (noteTP   < 0 || noteTP   > 20) cout << "Note invalide (0-20): "; } while (noteTP   < 0 || noteTP   > 20);
            cout << "Note CC (0-20): ";
            do { cin >> noteCC;   if (noteCC   < 0 || noteCC   > 20) cout << "Note invalide (0-20): "; } while (noteCC   < 0 || noteCC   > 20);
            cout << "Note EXAM (0-20): ";
            do { cin >> noteEXAM; if (noteEXAM < 0 || noteEXAM > 20) cout << "Note invalide (0-20): "; } while (noteEXAM < 0 || noteEXAM > 20);

            // Add the three controles with their respective weights
            etu->ajouterControle(codeModule, new controle("TP",   20, noteTP));
            etu->ajouterControle(codeModule, new controle("CC",   30, noteCC));
            etu->ajouterControle(codeModule, new controle("EXAM", 50, noteEXAM));
            db_save_etudiant(conn, etu);
            cout << "Controles ajoutes et sauvegardes. Ponderation: 20% + 30% + 50% = 100%\n";
            break;
        }
        case 8: {
            // --- Modify a specific grade (by module code and assessment type) ---
            string cne, codeModule, type;
            float nouvelleNote;
            cout << "CNE etudiant: ";      cin >> cne;
            etudiant* etu = NULL;
            for (size_t i = 0; i < etudiants.size(); i++) {
                if (etudiants[i]->getCNE() == cne) { etu = etudiants[i]; break; }
            }
            if (!etu) { cout << "Etudiant non trouve.\n"; break; }
            cout << "Code module: ";       cin >> codeModule;
            cout << "Type (TP/CC/EXAM): "; cin >> type;
            cout << "Nouvelle note (0-20): ";
            do { cin >> nouvelleNote; if (nouvelleNote < 0 || nouvelleNote > 20) cout << "Note invalide (0-20): "; } while (nouvelleNote < 0 || nouvelleNote > 20);
            if (etu->modifierNote(codeModule, type, nouvelleNote)) {
                db_save_etudiant(conn, etu);
                cout << "Note modifiee et sauvegardee.\n";
            } else {
                cout << "Module ou type non trouve.\n";
            }
            break;
        }
        case 9: {
            // --- Display all students with their modules and grades ---
            if (etudiants.empty()) { cout << "Aucun etudiant enregistre.\n"; break; }
            for (size_t i = 0; i < etudiants.size(); i++) {
                cout << "\n[" << i+1 << "] " << etudiants[i]->getNom() << " " << etudiants[i]->getPrenom()
                     << " | CNE: " << etudiants[i]->getCNE() << endl;
                etudiants[i]->afficherModules();
            }
            break;
        }
        case 10: {
            // --- Statistics sub-menu ---
            if (etudiants.empty()) { cout << "Aucun etudiant enregistre.\n"; break; }
            cout << "\n--- Statistiques ---\n";
            cout << "1. Taux de reussite\n";
            cout << "2. Meilleur etudiant\n";
            cout << "3. Etudiants en difficulte (moyenne < 10)\n";
            cout << "Choix: ";
            int choixStats = lireChoix();
            switch (choixStats) {
                case 1: {
                    // Calculate and display the pass rate
                    int admis = 0;
                    for (size_t i = 0; i < etudiants.size(); i++)
                        if (etudiants[i]->calculMoyenneGenerale() >= 10) admis++;
                    cout << "Admis: " << admis << "/" << etudiants.size() << endl;
                    cout << "Taux: " << (float)admis / etudiants.size() * 100.0 << "%\n";
                    break;
                }
                case 2: {
                    // Find and display the student with the highest overall average
                    etudiant* meilleur = etudiants[0];
                    float maxMoy = etudiants[0]->calculMoyenneGenerale();
                    for (size_t i = 1; i < etudiants.size(); i++) {
                        float moy = etudiants[i]->calculMoyenneGenerale();
                        if (moy > maxMoy) { maxMoy = moy; meilleur = etudiants[i]; }
                    }
                    cout << "Meilleur: " << meilleur->getNom() << " " << meilleur->getPrenom()
                         << " | Moyenne: " << maxMoy << endl;
                    break;
                }
                case 3: {
                    // List all students with an overall average below 10
                    bool trouve = false;
                    for (size_t i = 0; i < etudiants.size(); i++) {
                        float moy = etudiants[i]->calculMoyenneGenerale();
                        if (moy < 10) {
                            cout << etudiants[i]->getNom() << " " << etudiants[i]->getPrenom()
                                 << " | Moyenne: " << moy << endl;
                            trouve = true;
                        }
                    }
                    if (!trouve) cout << "Aucun etudiant en difficulte.\n";
                    break;
                }
                default: cout << "Choix invalide.\n"; break;
            }
            break;
        }
        case 11:
            // --- Logout: returns to the main login screen ---
            cout << "Deconnexion...\n";
            break;
        default:
            cout << "Choix invalide.\n";
            break;
    }
}

// ---------------------------------------------------------------
// gererMenuEtudiant()
// Displays the student (etudiant) read-only menu and handles:
//   1. View modules and grades
//   2. View overall average
//   3. Check admission decision
//   4. Best module
//   5. Weakest module
//   6. Note needed to pass a specific module
//   7. Logout
// Students cannot modify any data — read only.
// ---------------------------------------------------------------
void gererMenuEtudiant(etudiant* etu, int& choix) {
    system("pause");
    system("cls");
    cout << "\n--- Menu Etudiant : " << etu->getNom() << " " << etu->getPrenom() << " ---\n";
    cout << "1. Afficher mes modules et notes\n";
    cout << "2. Ma moyenne generale\n";
    cout << "3. Suis-je admis ?\n";
    cout << "4. Ma meilleure matiere\n";
    cout << "5. Ma matiere faible\n";
    cout << "6. Note necessaire pour reussir un module\n";
    cout << "7. Se deconnecter\n";
    cout << "Choix: ";
    choix = lireChoix();

    switch (choix) {
        case 1:
            // Display all enrolled modules and grades
            if (etu->modules.empty()) { cout << "Aucun module enregistre.\n"; break; }
            etu->afficherModules();
            break;
        case 2:
            // Display the weighted overall average
            cout << "Moyenne generale: " << etu->calculMoyenneGenerale() << endl;
            break;
        case 3:
            // Display "Admis" or "Ajourne"
            cout << "Decision: " << etu->decisionAcademique() << endl;
            break;
        case 4:
            // Display the module name with the highest average
            cout << "Meilleure matiere: " << etu->meilleurModule() << endl;
            break;
        case 5:
            // Display the module name with the lowest average
            cout << "Matiere faible: " << etu->moduleFaible() << endl;
            break;
        case 6: {
            // Calculate and display the minimum exam grade needed to pass a module
            string codeModule;
            cout << "Code module: "; cin >> codeModule;
            float n = etu->noteNecessaire(codeModule);
            if (n == -2)
                cout << "Vous avez deja valide ce module !\n";
            else if (n == -1)
                cout << "Module non trouve ou pas d'examen enregistre.\n";
            else if (n > 20)
                cout << "Impossible de rattraper ce module.\n";
            else
                cout << "Il vous faut au moins " << n << "/20 a l'examen.\n";
            break;
        }
        case 7:
            // Logout: returns to the main login menu
            cout << "Deconnexion...\n";
            break;
        default:
            cout << "Choix invalide.\n";
            break;
    }
}

// ---------------------------------------------------------------
// gererLogin()
// Main login/entry screen. Handles:
//   1. Teacher login (code + password "Admin")
//   2. Teacher registration (new account)
//   3. Student login (CNE only — no password required)
//   4. Exit application
//
// Returns:
//   1 = Teacher logged in (enseignantConnecte is set)
//   2 = Student logged in (etudiantConnecte is set)
//   3 = Exit requested
//   0 = Login failed or registration done (show menu again)
// ---------------------------------------------------------------
int gererLogin(vector<etudiant*>& etudiants, vector<enseignant*>& enseignants,
               etudiant*& etudiantConnecte, enseignant*& enseignantConnecte) {
    system("cls");
    cout << "\n=== Systeme Academique ===\n";
    cout << "1. Connexion Enseignant\n";
    cout << "2. S'inscrire comme Enseignant\n";
    cout << "3. Connexion Etudiant\n";
    cout << "4. Quitter\n";
    cout << "Choix: ";
    int choix = lireChoix();

    switch (choix) {
        case 1: {
            // --- Teacher login ---
            // Password is hardcoded as "Admin" for all teachers
            string code, pass_;
            cout << "Code enseignant: "; cin >> code;
            cout << "Password: ";
            pass_ = lireMotDePasse();
            string pass = "Admin"; // Hardcoded global password for all teacher accounts
            for (size_t i = 0; i < enseignants.size(); i++) {
                if (enseignants[i]->getCode() == code && pass == pass_) {
                    enseignantConnecte = enseignants[i];
                    cout << "Bienvenue, " << enseignants[i]->getNom() << " !\n";
                    return 1; // Signal: teacher logged in
                }
            }
            cout << "Code ou mot de passe incorrect.\n";
            return 0;
        }
        case 2: {
            // --- Teacher registration ---
            // Checks for duplicate code or CIN before creating the account
            string cin_, nom, prenom, code;
            cout << "--- Inscription Enseignant ---\n";
            cout << "CIN: ";             cin >> cin_;
            cout << "Nom: ";             cin >> nom;
            cout << "Prenom: ";          cin >> prenom;
            cout << "Code enseignant: "; cin >> code;
            for (size_t i = 0; i < enseignants.size(); i++) {
                if (enseignants[i]->getCode() == code) { cout << "Erreur : code deja utilise !\n"; return 0; }
                if (enseignants[i]->getCIN()  == cin_)  { cout << "Erreur : CIN deja utilise !\n";  return 0; }
            }
            enseignant* nouv = new enseignant(cin_, nom, prenom, code);
            enseignants.push_back(nouv);
            db_save_enseignant(conn, nouv); // Save new teacher to database
            cout << "Inscription reussie ! Connectez-vous maintenant.\n";
            return 0; // Return to login menu so teacher can log in
        }
        case 3: {
            // --- Student login (CNE only, no password) ---
            string cne;
            cout << "Votre CNE: "; cin >> cne;
            for (size_t i = 0; i < etudiants.size(); i++) {
                if (etudiants[i]->getCNE() == cne) {
                    etudiantConnecte = etudiants[i];
                    cout << "Bienvenue, " << etudiants[i]->getNom() << " !\n";
                    return 2; // Signal: student logged in
                }
            }
            cout << "CNE non reconnu.\n";
            return 0;
        }
        case 4:
            return 3; // Signal: exit the application
        default:
            cout << "Choix invalide.\n";
            return 0;
    }
}

// ---------------------------------------------------------------
// main()
// Application entry point.
//   1. Attempts to connect to the MariaDB database.
//   2. Loads all students and teachers from the database.
//   3. Runs the main login loop until the user chooses to exit.
//   4. Routes to the appropriate menu based on user role.
//   5. Cleans up all memory and closes the DB connection on exit.
// ---------------------------------------------------------------
int main() {
    vector<etudiant*>   etudiants;    // In-memory list of all students
    vector<enseignant*> enseignants;  // In-memory list of all teachers
    etudiant*   etudiantConnecte   = NULL; // Currently logged-in student (or NULL)
    enseignant* enseignantConnecte = NULL; // Currently logged-in teacher (or NULL)
    bool running = true;

    // Attempt to connect to the local MariaDB database
    if (!db_connect(conn)) {
        cout << "Attention: programme lance SANS base de donnees.\n";
    } else {
        // Load all existing data from the database into memory
        db_load(conn, etudiants);
        db_load_enseignants(conn, enseignants);
        cout << etudiants.size()   << " etudiant(s) charge(s).\n";
        cout << enseignants.size() << " enseignant(s) charge(s).\n";
    }

    // Main application loop — keeps running until the user selects "Quitter"
    while (running) {
        int role = gererLogin(etudiants, enseignants, etudiantConnecte, enseignantConnecte);

        switch (role) {
            case 1: {
                // Teacher session: loop in teacher menu until logout (choice 11)
                int choix = 0;
                while (choix != 11)
                    gererMenuEnseignant(etudiants, enseignantConnecte, choix);
                enseignantConnecte = NULL; // Clear session after logout
                break;
            }
            case 2: {
                // Student session: loop in student menu until logout (choice 7)
                int choix = 0;
                while (choix != 7)
                    gererMenuEtudiant(etudiantConnecte, choix);
                etudiantConnecte = NULL; // Clear session after logout
                break;
            }
            case 3:
                // Exit application
                cout << "Au revoir !\n";
                running = false;
                break;
        }
    }

    // Close the database connection
    if (conn) db_disconnect(conn);

    // Free all heap-allocated student and teacher objects to prevent memory leaks
    for (size_t i = 0; i < etudiants.size();   i++) delete etudiants[i];
    for (size_t i = 0; i < enseignants.size(); i++) delete enseignants[i];

    return 0;
}
