// ============================================================
// controle.cpp
// Implementation of the controle class.
// Each instance represents one graded assessment (TP, CC, EXAM)
// attached to a module, with its own weight and grade.
// ============================================================

#include "controle.h"

// Constructor: initializes type and percentage, then creates a new note with the given value
controle::controle(string t, float p, float val) : type(t), pourcentage(p) {
    n = new note(val); // Dynamically allocate a note object with the initial grade
}

// Destructor: frees the heap-allocated note to prevent memory leaks
controle::~controle() { delete n; }

// Returns the grade stored in the associated note object
float controle::getNote() const { return n->getNote(); }

// Returns the percentage weight of this assessment in the module grade
float controle::getPourcentage() const { return pourcentage; }

// Returns the type label of this assessment (e.g., "TP", "CC", "EXAM")
string controle::getType() const { return type; }

// Updates the grade through the note object (handles 0–20 clamping internally)
void controle::setNote(float val) { n->setNote(val); }
