// ============================================================
// module.h
// Represents an academic module (course) assigned to a student.
// A module has a code, title (intitule), coefficient, the
// teacher's code (codeEnseignant), a semester number, and a
// list of assessments (controles).
// ============================================================

#ifndef MODULE_H
#define MODULE_H

#include <string>
#include <vector>
#include "controle.h"
using namespace std;

class module {
public:
    string code;             // Short course code (e.g., "MATH101")
    string intitule;         // Full course name (e.g., "Mathematiques")
    int coefficient;         // Weight of this module in the student's overall average
    string codeEnseignant;   // Code of the teacher responsible for this module
    int semestre;            // Semester number this module belongs to
    vector<controle*> controles; // List of all assessments for this module

    // Constructor: sets all module fields
    module(string c, string i, int coef, string ens, int sem);

    // Destructor: frees all dynamically allocated controle objects
    ~module();

    // Adds a new assessment to this module's list
    void ajouterControle(controle* c);

    // Finds and updates the grade of the assessment matching the given type
    // Returns true if the assessment was found and updated, false otherwise
    bool modifierNote(const string& type, float nouvelleNote);

    // Calculates and returns the weighted average for this module
    // Formula: sum(grade_i * percentage_i / 100) across all controles
    float moyenneModule() const;
};

#endif
