// ============================================================
// Database.cpp
// Implementation of all database interaction functions.
// Connects to a local MariaDB/MySQL instance (via XAMPP) and
// performs CRUD operations on etudiants, enseignants, modules,
// and controles tables.
//
// Connection details (hard-coded):
//   Host     : 127.0.0.1 (localhost)
//   User     : root
//   Password : (empty)
//   Database : khdaminshalah
//   Port     : 3306
// ============================================================

#include "Database.h"
#include <iostream>
#include <string>
using namespace std;

// Opens a connection to the local MySQL/MariaDB database.
// Disables SSL to avoid issues with XAMPP's default configuration.
// Sets the character encoding to UTF-8.
// Returns true if connection succeeded, false otherwise.
bool db_connect(MYSQL*& conn) {
    conn = mysql_init(NULL); // Initialize the MySQL connection object
    if (!conn) { cout << "mysql_init failed.\n"; return false; }

    // Disable SSL enforcement (not needed for local XAMPP connections)
    my_bool ssl = 0;
    mysql_options(conn, MYSQL_OPT_SSL_ENFORCE, (const char*)&ssl);
    mysql_options(conn, MYSQL_OPT_SSL_VERIFY_SERVER_CERT, (const char*)&ssl);

    // Attempt to connect to the database with the given credentials
    if (!mysql_real_connect(conn, "127.0.0.1", "root", "", "khdaminshalah", 3306, NULL, 0)) {
        cout << "Erreur connexion DB: " << mysql_error(conn) << "\n";
        mysql_close(conn); conn = NULL; return false;
    }

    mysql_set_character_set(conn, "utf8"); // Ensure French characters display correctly
    cout << "Base de donnees connectee.\n";
    return true;
}

// Closes the MySQL connection and releases all associated memory.
void db_disconnect(MYSQL* conn) {
    if (conn) mysql_close(conn);
}

// Loads all students from the database.
// First fetches all rows from `etudiants` (excluding those who are also teachers).
// Then for each student, fetches their modules from `modules`,
// and for each module, fetches all related controles (assessments).
void db_load(MYSQL* conn, vector<etudiant*>& etudiants) {
    if (!conn) return;

    // Query: get all students who are NOT also listed as teachers
    if (mysql_query(conn, "SELECT e.cin, e.nom, e.prenom, e.cne FROM etudiants e "
                          "WHERE e.cin NOT IN (SELECT cin FROM enseignants)")) {
        cout << "Erreur chargement etudiants: " << mysql_error(conn) << "\n";
        return;
    }
    MYSQL_RES* res = mysql_store_result(conn); // Store the result set
    MYSQL_ROW T;
    // Iterate over each row and create an etudiant object
    while ((T = mysql_fetch_row(res))) {
        etudiants.push_back(new etudiant(
            string(T[0]), string(T[1]), string(T[2]), string(T[3])
        ));
    }
    mysql_free_result(res); // Free the result set memory

    // For each student loaded, now fetch their modules
    for (size_t i = 0; i < etudiants.size(); i++) {
        string cin_ = etudiants[i]->personne::getCIN();
        // Query modules for this specific student by CIN
        string q = "SELECT id, code, intitule, coefficient, codeEnseignant, semestre"
                   " FROM modules WHERE etudiant_cin='" + cin_ + "'";
        if (mysql_query(conn, q.c_str())) continue;

        MYSQL_RES* resM = mysql_store_result(conn);
        MYSQL_ROW TM;
        while ((TM = mysql_fetch_row(resM))) {
            string mid_str = string(TM[0]); // Module DB ID (used to fetch controles)
            int coef = 0, sem = 0;
            sscanf(TM[3], "%d", &coef); // Parse coefficient as integer
            sscanf(TM[5], "%d", &sem);  // Parse semester as integer
            module* m = new module(string(TM[1]), string(TM[2]), coef, string(TM[4]), sem);
            etudiants[i]->ajouterModule(m); // Attach module to this student

            // Now fetch all controles (assessments) for this module using its DB ID
            string qc = "SELECT type, pourcentage, note FROM controles WHERE module_id=" + mid_str;
            if (!mysql_query(conn, qc.c_str())) {
                MYSQL_RES* resC = mysql_store_result(conn);
                MYSQL_ROW TC;
                while ((TC = mysql_fetch_row(resC))) {
                    float pct = 0, note = 0;
                    sscanf(TC[1], "%f", &pct);  // Parse percentage as float
                    sscanf(TC[2], "%f", &note); // Parse grade as float
                    m->ajouterControle(new controle(string(TC[0]), pct, note));
                }
                mysql_free_result(resC);
            }
        }
        mysql_free_result(resM);
    }
}

// Saves (inserts or updates) a single student and all their data to the database.
// Strategy:
//   1. Upsert the student row (INSERT ... ON DUPLICATE KEY UPDATE)
//   2. Delete all existing modules for this student (to avoid duplicates)
//   3. Re-insert all modules with fresh auto-increment IDs
//   4. For each module, insert all its controles linked by the new module ID
void db_save_etudiant(MYSQL* conn, etudiant* e) {
    if (!conn || !e) return;

    string cin_   = e->personne::getCIN();
    string nom    = e->getNom();
    string prenom = e->getPrenom();
    string cne    = e->getCNE();

    // Build the upsert query for the student row
    string q = "INSERT INTO etudiants (cin, nom, prenom, cne) VALUES ('"
             + cin_ + "','" + nom + "','" + prenom + "','" + cne + "')"
             + " ON DUPLICATE KEY UPDATE"
             + " nom='"    + nom    + "',"
             + " prenom='" + prenom + "',"
             + " cne='"    + cne    + "'";
    if (mysql_query(conn, q.c_str())) {
        cout << "Erreur save etudiant: " << mysql_error(conn) << "\n";
        return;
    }

    // Delete all existing modules for this student before re-inserting
    // (cascades to delete associated controles via DB foreign key or is handled separately)
    string del = "DELETE FROM modules WHERE etudiant_cin='" + cin_ + "'";
    mysql_query(conn, del.c_str());

    // Re-insert each module and its controles
    for (size_t i = 0; i < e->modules.size(); i++) {
        module* m = e->modules[i];
        char bufM[512];
        sprintf(bufM,
            "INSERT INTO modules (code, intitule, coefficient, codeEnseignant, semestre, etudiant_cin)"
            " VALUES ('%s','%s',%d,'%s',%d,'%s')",
            m->code.c_str(), m->intitule.c_str(), m->coefficient,
            m->codeEnseignant.c_str(), m->semestre, cin_.c_str());
        if (mysql_query(conn, bufM)) { cout << "Erreur save module: " << mysql_error(conn) << "\n"; continue; }

        // Get the auto-generated ID of the just-inserted module row
        int mid = (int)mysql_insert_id(conn);

        // Insert each controle linked to this module's ID
        for (size_t j = 0; j < m->controles.size(); j++) {
            controle* c = m->controles[j];
            char bufC[256];
            sprintf(bufC,
                "INSERT INTO controles (type, pourcentage, note, module_id) VALUES ('%s',%.2f,%.2f,%d)",
                c->getType().c_str(), c->getPourcentage(), c->getNote(), mid);
            if (mysql_query(conn, bufC))
                cout << "Erreur save controle: " << mysql_error(conn) << "\n";
        }
    }
}

// Deletes a student from the database by CNE.
// First resolves the CIN from the CNE, then deletes the student row by CIN.
// (Modules and controles are removed via the DELETE on etudiants or cascade.)
void db_delete_etudiant(MYSQL* conn, const string& cne) {
    if (!conn) return;
    // Look up the CIN corresponding to this CNE
    string q = "SELECT cin FROM etudiants WHERE cne='" + cne + "'";
    if (mysql_query(conn, q.c_str())) return;
    MYSQL_RES* res = mysql_store_result(conn);
    MYSQL_ROW T = mysql_fetch_row(res);
    if (!T) { mysql_free_result(res); return; } // CNE not found in DB
    string cin_ = string(T[0]);
    mysql_free_result(res);
    // Delete the student row using their CIN
    mysql_query(conn, ("DELETE FROM etudiants WHERE cin='" + cin_ + "'").c_str());
}

// Iterates over all students in the vector and saves each one to the database.
// Useful for a bulk "save all" operation.
void db_save_all(MYSQL* conn, vector<etudiant*>& etudiants) {
    if (!conn) return;
    for (size_t i = 0; i < etudiants.size(); i++)
        db_save_etudiant(conn, etudiants[i]);
}

// Loads all teachers from the `enseignants` table into the enseignants vector.
void db_load_enseignants(MYSQL* conn, vector<enseignant*>& enseignants) {
    if (!conn) return;
    if (mysql_query(conn, "SELECT cin, nom, prenom, code FROM enseignants")) {
        cout << "Erreur chargement enseignants: " << mysql_error(conn) << "\n";
        return;
    }
    MYSQL_RES* res = mysql_store_result(conn);
    MYSQL_ROW T;
    while ((T = mysql_fetch_row(res))) {
        enseignants.push_back(new enseignant(
            string(T[0]), string(T[1]), string(T[2]), string(T[3])
        ));
    }
    mysql_free_result(res);
}

// Inserts or updates a teacher record in the database.
// Uses INSERT ... ON DUPLICATE KEY UPDATE (keyed on CIN).
void db_save_enseignant(MYSQL* conn, enseignant* e) {
    if (!conn || !e) return;
    char buf[512];
    sprintf(buf,
        "INSERT INTO enseignants (cin, nom, prenom, code) VALUES ('%s','%s','%s','%s')"
        " ON DUPLICATE KEY UPDATE nom='%s', prenom='%s', code='%s'",
        e->getCIN().c_str(), e->getNom().c_str(), e->getPrenom().c_str(), e->getCode().c_str(),
        e->getNom().c_str(), e->getPrenom().c_str(), e->getCode().c_str());
    if (mysql_query(conn, buf))
        cout << "Erreur save enseignant: " << mysql_error(conn) << "\n";
}
