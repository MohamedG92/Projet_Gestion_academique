// ============================================================
// etudiant.cpp
// Implementation of the etudiant (student) class.
// Manages a student's modules, grades, and academic statistics.
// ============================================================

#include "etudiant.h"
#include <iostream>
using namespace std;

// Constructor: initializes base class personne and the student's CNE
etudiant::etudiant(string cin_, string nom_, string prenom_, string cne_)
    : personne(cin_, nom_, prenom_), cne(cne_) {}

// Destructor: frees all dynamically allocated module objects to prevent memory leaks
etudiant::~etudiant() {
    for (size_t i = 0; i < modules.size(); i++) {
        delete modules[i];
    }
}

// Returns the student's CNE (student enrollment number)
string etudiant::getCNE() const { return cne; }

// Updates the student's CNE
void etudiant::setCNE(string c) { cne = c; }

// Appends a new module to the student's list of enrolled modules
void etudiant::ajouterModule(module* m) {
    modules.push_back(m);
}

// Finds a module by code, removes it from the list, and deletes it from memory.
// Prints a confirmation or "not found" message to the console.
void etudiant::supprimerModule(const string& codeModule) {
    for (size_t i = 0; i < modules.size(); i++) {
        if (modules[i]->code == codeModule) {
            delete modules[i];                        // Free the module's memory
            modules.erase(modules.begin() + i);       // Remove the pointer from the vector
            cout << "Module supprime avec succes.\n";
            return;
        }
    }
    cout << "Module non trouve.\n";
}

// Finds the module matching codeModule and adds the given controle to it.
// Prints an error if the module does not exist.
void etudiant::ajouterControle(const string& codeModule, controle* c) {
    for (size_t i = 0; i < modules.size(); i++) {
        if (modules[i]->code == codeModule) {
            modules[i]->ajouterControle(c);
            return;
        }
    }
    cout << "Module non trouve pour cet etudiant.\n";
}

// Finds the module by code, then delegates to module::modifierNote to update
// the grade of the matching assessment type.
// Returns true on success, false if module not found.
bool etudiant::modifierNote(const string& codeModule, const string& type, float nouvelleNote) {
    for (size_t i = 0; i < modules.size(); i++) {
        if (modules[i]->code == codeModule) {
            return modules[i]->modifierNote(type, nouvelleNote);
        }
    }
    return false;
}

// Calculates the student's overall average using a coefficient-weighted formula:
//   general_average = sum(module_average * coefficient) / sum(coefficients)
// Returns 0 if there are no modules.
float etudiant::calculMoyenneGenerale() const {
    float somme = 0;
    int totalCoef = 0;
    for (size_t i = 0; i < modules.size(); i++) {
        somme += modules[i]->moyenneModule() * modules[i]->coefficient;
        totalCoef += modules[i]->coefficient;
    }
    if (totalCoef == 0) return 0;
    return somme / totalCoef;
}

// Returns the academic decision string:
//   "Admis"   if overall average >= 10
//   "Ajourne" if overall average < 10
string etudiant::decisionAcademique() const {
    return calculMoyenneGenerale() >= 10 ? "Admis" : "Ajourne";
}

// Iterates through all modules and returns the name (intitule) of the one
// with the highest weighted average.
string etudiant::meilleurModule() const {
    if (modules.empty()) return "Aucun module";
    string meilleur = modules[0]->intitule;
    float maxMoy = modules[0]->moyenneModule();
    for (size_t i = 1; i < modules.size(); i++) {
        float moy = modules[i]->moyenneModule();
        if (moy > maxMoy) { maxMoy = moy; meilleur = modules[i]->intitule; }
    }
    return meilleur;
}

// Iterates through all modules and returns the name (intitule) of the one
// with the lowest weighted average.
string etudiant::moduleFaible() const {
    if (modules.empty()) return "Aucun module";
    string faible = modules[0]->intitule;
    float minMoy = modules[0]->moyenneModule();
    for (size_t i = 1; i < modules.size(); i++) {
        float moy = modules[i]->moyenneModule();
        if (moy < minMoy) { minMoy = moy; faible = modules[i]->intitule; }
    }
    return faible;
}

// Calculates the minimum grade needed on the EXAM assessment to reach an average of 10.
// Formula: needed = (10 - contrib_non_exam) / (exam_percentage / 100)
//   where contrib_non_exam = sum of grade * weight for all non-EXAM assessments
//
// Return values:
//   -1  : module not found, or no EXAM assessment registered
//    0  : student already has >= 10 without the exam
//   > 20: impossible to pass (would need more than 20/20)
float etudiant::noteNecessaire(const string& codeModule) const {
    for (size_t i = 0; i < modules.size(); i++) {
        if (modules[i]->code == codeModule) {
            float contrib = 0;   // Contribution from non-EXAM assessments
            float examPct = 0;   // Weight of the EXAM assessment
            for (size_t j = 0; j < modules[i]->controles.size(); j++) {
                controle* c = modules[i]->controles[j];
                if (c->getType() != "EXAM")
                    contrib += c->getNote() * c->getPourcentage() / 100.0;
                else
                    examPct = c->getPourcentage();
            }
            if (examPct == 0) return -1; // No EXAM found
            float needed = (10.0 - contrib) / (examPct / 100.0);
            if (needed < 0) return 0;    // Already passing without exam
            if (needed > 20) return 21;  // Impossible to recover
            return needed;
        }
    }
    return -1; // Module not found
}

// Prints a formatted list of all modules and their assessments to the console.
// For each module: shows code, title, coefficient, teacher, semester,
// then each controle type/weight/grade, and finally the module average.
void etudiant::afficherModules() const {
    for (size_t i = 0; i < modules.size(); i++) {
        module* m = modules[i];
        cout << "  Module: " << m->code << " - " << m->intitule
             << " | Coef: " << m->coefficient
             << " | Enseignant: " << m->codeEnseignant
             << " | Semestre: " << m->semestre << endl;
        // Print each individual assessment and its grade
        for (size_t j = 0; j < m->controles.size(); j++) {
            controle* c = m->controles[j];
            cout << "    " << c->getType() << " (" << c->getPourcentage() << "%): " << c->getNote() << endl;
        }
        // Print module average only if there are assessments
        if (!m->controles.empty())
            cout << "    Moyenne module: " << m->moyenneModule() << endl;
    }
}
