// ============================================================
// etudiant.h
// Represents a student (etudiant) in the academic system.
// Inherits from personne and adds a CNE (student number),
// a list of enrolled modules, and methods to manage grades,
// calculate averages, and determine academic outcomes.
// ============================================================

#ifndef ETUDIANT_H
#define ETUDIANT_H

#include <string>
#include <vector>
#include "personne.h"
#include "module.h"
#include "controle.h"
using namespace std;

// Student class — extends personne with CNE and academic data
class etudiant : public personne {
private:
    string cne; // Student enrollment number (CNE: Code National de l'Etudiant)

public:
    vector<module*> modules; // List of modules this student is enrolled in

    // Constructor: initializes CIN, nom, prenom (via personne) and CNE
    etudiant(string cin_, string nom_, string prenom_, string cne_);

    // Destructor: frees all dynamically allocated module objects
    ~etudiant();

    // Returns the student's CNE
    string getCNE() const;

    // Updates the student's CNE
    void setCNE(string c);

    // Adds a module to the student's module list
    void ajouterModule(module* m);

    // Removes a module by its code and frees its memory
    void supprimerModule(const string& codeModule);

    // Adds a controle (assessment) to the specified module
    void ajouterControle(const string& codeModule, controle* c);

    // Updates the grade of a specific assessment type in a given module
    // Returns true if successful, false if module or type not found
    bool modifierNote(const string& codeModule, const string& type, float nouvelleNote);

    // Calculates the student's overall weighted average across all modules
    float calculMoyenneGenerale() const;

    // Returns "Admis" if average >= 10, otherwise "Ajourne"
    string decisionAcademique() const;

    // Returns the name of the module with the highest average
    string meilleurModule() const;

    // Returns the name of the module with the lowest average
    string moduleFaible() const;

    // Calculates the minimum exam grade needed to pass a given module (average >= 10)
    // Returns -1 if module not found or no EXAM assessment exists
    // Returns a value > 20 if it is mathematically impossible to pass
    float noteNecessaire(const string& codeModule) const;

    // Prints all modules and their assessments/grades to the console
    void afficherModules() const;
};

#endif
