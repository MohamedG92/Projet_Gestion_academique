// ============================================================
// Database.h
// Header for all database functions used by the application.
// Uses the MariaDB/MySQL C API (mysql.h) to communicate with
// the local database "khdaminshalah" running on XAMPP.
//
// Tables expected in the database:
//   - etudiants   (cin, nom, prenom, cne)
//   - enseignants (cin, nom, prenom, code)
//   - modules     (id, code, intitule, coefficient, codeEnseignant, semestre, etudiant_cin)
//   - controles   (id, type, pourcentage, note, module_id)
// ============================================================

#ifndef DATABASE_H
#define DATABASE_H

#include <mysql.h>
#include <vector>
#include <string>
#include "etudiant.h"
#include "enseignant.h"
using namespace std;

// --- Connection management ---

// Initializes and opens a MySQL connection to the local database.
// Returns true on success, false on failure.
// The conn pointer is updated to point to the active connection.
bool db_connect(MYSQL*& conn);

// Closes the MySQL connection and frees associated resources.
void db_disconnect(MYSQL* conn);

// --- Student (etudiant) database operations ---

// Loads all students from the database into the etudiants vector,
// including their associated modules and controles (assessments).
void db_load(MYSQL* conn, vector<etudiant*>& etudiants);

// Inserts or updates a single student and all their modules/controles.
// Uses INSERT ... ON DUPLICATE KEY UPDATE for upsert behavior.
// Deletes and re-inserts all modules to keep data in sync.
void db_save_etudiant(MYSQL* conn, etudiant* e);

// Deletes a student from the database by their CNE.
// Also removes associated modules and controles via DB cascade/triggers or direct delete.
void db_delete_etudiant(MYSQL* conn, const string& cne);

// Saves every student in the etudiants vector to the database.
// Calls db_save_etudiant for each entry.
void db_save_all(MYSQL* conn, vector<etudiant*>& etudiants);

// --- Teacher (enseignant) database operations ---

// Loads all teachers from the database into the enseignants vector.
void db_load_enseignants(MYSQL* conn, vector<enseignant*>& enseignants);

// Inserts or updates a single teacher record in the database.
void db_save_enseignant(MYSQL* conn, enseignant* e);

#endif
