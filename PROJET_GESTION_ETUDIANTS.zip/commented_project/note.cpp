// ============================================================
// note.cpp
// Implementation of the note class.
// Handles storage and validation of a single grade (0–20).
// ============================================================

#include "note.h"

// Constructor: stores the initial grade value
note::note(float val) : n(val) {}

// Prompts the user to enter a grade from the console.
// Automatically clamps the value to the valid range [0, 20].
void note::saisir() {
    cout << "Note (0-20) : ";
    cin >> n;
    if (n < 0) n = 0;   // Clamp: no grade below 0
    if (n > 20) n = 20; // Clamp: no grade above 20
}

// Displays the grade value to the console (no newline)
void note::afficher() const {
    cout << n;
}

// Returns the current grade value
float note::getNote() const { return n; }

// Updates the grade value and clamps it to [0, 20]
void note::setNote(float val) {
    if (val < 0) val = 0;
    if (val > 20) val = 20;
    n = val;
}
