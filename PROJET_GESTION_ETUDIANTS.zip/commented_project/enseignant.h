// ============================================================
// enseignant.h
// Represents a teacher (enseignant) in the academic system.
// Inherits from personne (CIN, nom, prenom) and adds a
// unique teacher code used for login and module assignment.
// ============================================================

#ifndef ENSEIGNANT_H
#define ENSEIGNANT_H

#include "personne.h"
#include <string>
using namespace std;

// Teacher class — extends personne with a unique teacher code
class enseignant : public personne {
    string codeEnseignant; // Unique identifier code for this teacher (used for login)

public:
    // Constructor: initializes CIN, nom, prenom (via personne), and teacher code
    enseignant(string cin_, string nom_, string prenom_, string code);

    // Returns the unique teacher code
    string getCode() const;
};

#endif
