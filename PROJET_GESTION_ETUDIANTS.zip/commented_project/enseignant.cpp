// ============================================================
// enseignant.cpp
// Implementation of the enseignant (teacher) class.
// Inherits identity from personne and adds a teacher code.
// ============================================================

#include "enseignant.h"

// Constructor: passes CIN, nom, prenom to the personne base class
// and stores the teacher's unique code
enseignant::enseignant(string cin_, string nom_, string prenom_, string code)
    : personne(cin_, nom_, prenom_), codeEnseignant(code) {}

// Returns the teacher's unique identifier code
string enseignant::getCode() const { return codeEnseignant; }
